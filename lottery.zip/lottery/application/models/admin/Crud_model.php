<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Crud_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }
    function get_package_title($package_id) {


        return $this->db->get_where('packages', array('id' => $package_id))->row()->title;
        
    }
     public function setting(){
        return $this->db->get_where('ci_general_settings', array('id' => 1))->row()->logo;
    }
    public function get_email(){
        return $this->db->get_where('ci_general_settings', array('id' => 1))->row()->email_from;
    }
    function get_no_ticket($package_id) {


        return $this->db->get_where('packages', array('id' => $package_id))->row()->no_of_tickets;
        
    }
    function user_package($user_id) {
        $res = $this->db->get_where('ci_users', array('id' => $user_id))->result_array();
        foreach ($res as $row)
        return $row['package'];
    }
    function get_user_package($user_id) {
        $this->db->select('
        packages.id ,
        packages.title ,
        packages.no_of_tickets 
    ');
    $this->db->join('packages','ci_users.package = packages.id','left');
    $this->db->where('ci_users.id' , $user_id);
    return $this->db->get('ci_users')->result_array();

      
    }




}