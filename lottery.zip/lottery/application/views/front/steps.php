<div class="container">
	<div class="featured-2" id="easysteps">
		<div class="container">
			<div class="featured-text">
				<h2>3 Easy Steps</h2>
				<hr>
			</div>
		</div>
		<div class="container">
			<div class="feature-3-box-container">
				<div class="box-1">
					<img src="<?= base_url('assets');?>/images/template/1.png" alt="Choose your Numbers">
					<div class="title" style="color: #6BB64A;">Pick Your Numbers</div>
					<div class="details"><p style="color: black;">Choose a set of numbers using the grid below, your ticket details will be safely stored.</p></div>
				</div>
				<div class="box-2">
					<img src="<?= base_url('assets');?>/images/template/2.png" alt="Enter your name and Email to register.">
					<div class="title" style="color: #6BB64A;">Enter Details</div>
					<div class="details"><p style="color: black">Enter your name and email address and wait for the confirmation email to arrive in your inbox.</p></div>
				</div>
				<div class="box-3">
					<img src="<?= base_url('assets');?>/images/template/3.png" alt="Win prizes worth up to £10,000">
					<div class="title" style="color: #6BB64A;">Win</div>
					<div class="details"><p style="color: #555;">Log in after the draw to see if you are the latest Small Lottery winner!</p></div>
				</div>
				
          
			</div>
		</div>
	</div>
</div>