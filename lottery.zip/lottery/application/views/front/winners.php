<div class="breadcrumbs">
    <div class="container">
        <ol class="breadcrumb" itemscope itemtype="http://schema.org/BreadcrumbList">

            <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                <meta itemprop="position" content="1">
                <a href="<?php echo base_url() ?>" title="samll-lottery.com Home" itemprop="item">
                    <span itemprop="name">small-Lottery.com Home</span>
                </a>
            </li>

            <li>winners </li>

        </ol>
    </div>
</div>
<div class="container winners">

    <h3> <?php foreach ($time as $t) ?>
        <marquee>Draw: <?php echo $t; ?></marquee>
    </h3>
    <h3 id="demo"></h3>

    <article>
        <div class="featured-text">

            <h1>small Lottery Winners</h1>

            <p>As well as offering fantastic daily and weekly prizes, small Lottery runs regular giveaways for even more chances to win! Check out some of the great prizes that have been given away and learn more about the lucky competition winners.</p>
            <hr>

        </div>
    </article>
    <?php foreach($winners as $winner){ ?>
    <section class="generic-box">

        <img src="<?= base_url('uploads/').$winner['image'] ?>"  Width="130px" alt="Claire Lee" class="fluidimg" />
        <div class="column col-wide">
            <p><?= $winner['message'] ?></p>
            <strong><span><?= $winner['name'] ?></span></strong>
        </div><br class="clear">


    </section>
    <?php }?>

    <script>
        // Set the date we're counting down to
        var x = "<?php echo $dat ?>";
        var countDownDate = new Date(x).getTime();

        // Update the count down every 1 second
        var x = setInterval(function() {

            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Output the result in an element with id="demo"
            document.getElementById("demo").innerHTML = "Live In : " + hours + ":" +
                minutes + ":" + seconds;

            // If the count down is over, write some text 
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("demo").innerHTML = "EXPIRED";
            }
        }, 1000);
    </script>

</div>