<div class="container account-settings">
    <h1>Dashboard</h1>
    <?php if ($this->session->flashdata('success')) { ?>
			<h3 class="alert-success" >
				<?php echo $this->session->flashdata('success'); ?>
			</h3>
		<?php } ?>
		<?php if ($this->session->flashdata('error')) { ?>
			<h3 class="alert-warning" >
				<?php echo $this->session->flashdata('error'); ?>
			</h3>
		<?php } ?>
     
    <div class="main">
  
        <div class="generic-box-half no-lm">
            <h2>Package Details</h2>
            <div class="account-box">
           
                <div class="title">Your Purchased Package</div>
<?php if($package==0){ ?>
<p>No package</p>
<?php } else{?>
            <p><?php echo $this->crud_model->get_package_title($package) ?> </p>
<?php } ?>
            </div>
            <div class="account-box">

                <div class="title">Total Tickets</div>
                <?php if($package==0){ ?>
<p>No ticket</p>
<?php } else{?>
            <p><?php echo $this->crud_model->get_no_ticket($package) ?> </p>
<?php } ?>

            </div>

        </div>


        <div class="generic-box-half">
            <h2>Tikcts details</h2>
            <div class="account-box">
                <div class="title">No of Generated Tickets</div>
                <p></p>
            </div>
            <div class="account-box">

                <div class="title">Remaining Tickets</div>
                <p></p>

            </div>





        </div>






    </div>

</div>