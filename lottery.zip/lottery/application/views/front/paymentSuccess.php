<?php

print_r($packages);
echo "<br>";
print_r($payment);
?>