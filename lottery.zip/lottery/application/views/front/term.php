<div class="container how-it-works">
    <article>
        <header>
            <h1>Small Lottery Terms and Conditions</h1>
        </header>
        <div class="main">
            <section class="generic-box">
                <ul class="list">
                    <p><strong>Entrants will be deemed to have accepted these rules, and agreed to be bound by them, when taking part in the ‘small Lottery’ small prize draw. No payment is required in order to enter or to claim a prize. If no participants match the winning numbers for a particular draw, there will be no winner of the main prize for that draw.</strong></p>

                    <p><strong>Who may enter</strong></p>
                    <li>This small prize draw (“Promotion”) is open to anyone aged 18 or over except where prohibited by law.</li>
                    <li>Employees (or family members of employees) of any group company of the Promoter, companies associated with the Promotion or the prizes, and all affiliates of such companies, are excluded from taking part in this Promotion and from winning any prize.</li>
                    <li>All entries must be received by the times stated above in order to qualify for the relevant draw. </li>
                    <li>Maximum of one entry per person per Daily Draw and per Weekly Draw. </li>
                    <li>Tickets are electronically stored in your <em>small Lottery</em> account and are only valid for the draw stated on that individual ticket. </li>
                    <li>The winning numbers will be selected at random by an automated method. </li>

                    <p><strong>Prize</strong></p>
                    <li>To win a prize you must match all six numbers. If no one matches all six numbers in a Daily Draw or Weekly Draw, no prize will be awarded for that draw. </li>
                    <li>The prizes are:</li>
                    <li>Entries must not be made through agents or third parties.</li>
                    <li>Incomplete entries will be disqualified and will not be counted.</li>
                    <li>The Promoter’s decision is final and binding in all respects on all entrants. No correspondence will be entered into. Entries that do not comply in full with these rules will be disqualified. </li>
                    <li>If the Promoter has grounds to suspect any entrant or third party of cheating, deception or fraudulent or unsportsman-like conduct of any kind (including, without limitation, manipulating the promotion, choice of prize winner(s) or any entry) the Promoter reserves the right (in its sole discretion) to disqualify any entrant, entry or person it reasonably believes to be responsible for, or associated with, such activity. </li>
                    <li>The Promoter reserves the right to amend these rules, or to withdraw the Promotion, or to cancel any draw, at any time. Notice of any such changes, withdrawals or cancellations may be placed on the website in the Promoter’s absolute discretion. </li>

             

                    <div>
                    </div>

                </ul>

            </section>

        </div>

</div>