<div class="container account-settings">
    

    <h1>Account Settings</h1>
    <?php if ($this->session->flashdata('success')) { ?>
        <h3 class="alert-success">
            <?php echo $this->session->flashdata('success'); ?>
        </h3>
    <?php } ?>
    <?php if ($this->session->flashdata('error')) { ?>
        <h3 class="alert-warning">
            <?php echo $this->session->flashdata('error'); ?>
        </h3>
    <?php } ?>

    <div class="main">
   
        <div class="generic-box">

            <h2>Change Password</h2>

            <form id="form" name="form" action="<?= base_url('change_password') ?>" method="post" onSubmit="return checkForm();">

                <div class="fifty-percent pull-left">
                    <label for="CurrentPassword">Current Password<span class="alert">*</span></label>

                    <input id="CurrentPassword" name="CurrentPassword" type="password" size="30" maxlength="255" placeholder="Current Password" class="form-control" required />

                </div>

                <div class="fifty-percent pull-right">
                    <label for="NewPassword">New Password<span class="alert">*</span></label>

                    <input id="NewPassword" name="Password" type="text" size="30" maxlength="255" placeholder="New Password" class="form-control" required />


                  
                </div>

                <input id="Submit" type="submit" name="btn1" value="Update" class="btn" />


            </form>

        </div>



    </div>
</div>