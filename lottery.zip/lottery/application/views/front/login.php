<div class="breadcrumbs">
	<div class="container">
		<ol class="breadcrumb" itemscope itemtype="http://schema.org/BreadcrumbList">
		
		    <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="1">
		        <a href="#" title="" itemprop="item">
		        	<span itemprop="name"></span>
		        </a>
		    </li>
		    
		    
		    	<li>login </li>
            
            
		</ol>
	</div>
</div>


<div class="container login">

	<div class="login-container">
	<?php if ($this->session->flashdata('success')) { ?>
			<h3 class="alert-success" >
				<?php echo $this->session->flashdata('success'); ?>
			</h3>
		<?php } ?>
		<?php if ($this->session->flashdata('error')) { ?>
			<h3 class="alert-warning" >
				<?php echo $this->session->flashdata('error'); ?>
			</h3>
		<?php } ?>
	
			<h1>Login to Small Lottery</h1>
			
						<script type="text/javascript">
						
							function checkForm1() {
								if (document.getElementById("Email").value == "") {
									alert("Please enter your email address.");
									document.getElementById("Email").focus();
									return false;
								} else {
									apos = document.getElementById("Email").value.indexOf("@");
									dotpos = document.getElementById("Email").value.lastIndexOf(".");
			
									if (apos < 1 || dotpos - apos < 2) {
										alert("Please enter a valid email address.");
										document.getElementById("Email").focus();
										return false;
									}
								}
			
								if (document.getElementById("Password").value == "") {
									alert("Please enter a password.");
									document.getElementById("Password").focus();
									return false;
								}
			
								
			
								return true;
							}
					
						</script>
						
						<div class="fifty-percent pull-left">
			
							<form id="form" name="form" method="post" action ="<?=  base_url('login') ?>" onSubmit="return checkForm1();">
			
								<label for="EmailAddress">Email Address<span class="alert">*</span></label>
			
								<input class="form-control" id="Email" name="email" type="email" size="30" maxlength="255" value="" />
								
			
								<label for="Password">Password<span class="alert">*</span></label>
			
								<input class="form-control" id="Password" name="password" type="password" size="30" maxlength="255" />
								
			
								<a href="forgotten-password.html" title="Forgotten Password" class="bottom-link">Forgotten your password?</a>
			
								<input id="Submit" name="btn2" type="submit" value="Login" class="btn" />
			
								<input id="Login" name="Login" type="hidden" value="1" />
			
							</form>
                            
                            <div class="register-box">New to Small Lottery? <a title="Join Free Lottery" href="<?php echo base_url('register'); ?>"><span>Join Now</span></a></div>
			
							<div class="bottom-text"><span class="alert">*</span> Indicates required fields</div>
							
						</div>
					
	</div>

</div>