<div class="breadcrumbs">
	<div class="container">
		<ol class="breadcrumb" itemscope itemtype="http://schema.org/BreadcrumbList">
		
		    <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="1">
		        <a href="<?php echo base_url(); ?>" title="small-lottery.com Home" itemprop="item">
		        	<span itemprop="name">small-Lottery.com Home</span>
		        </a>
		    </li>
		    
		    
		    	<li>help </li>
            
            
		</ol>
	</div>
</div>
<div class="container help-page">
	<article>
		<header class="featured-text">
			<h1>Need Help?</h1>
			<p>You're ready to play Small Lottery games and win big, but you need a little assistance. Don't worry - you've come to the right place!</p>
			<hr>
		</header>
		<div class="main">

			<section>
				<h2>Registering</h2>
				<p>Registration is entirely small and is easy to do. When you create an account, you'll be guided through the whole process, from filling in your details to verifying your account. You can visit the <a href="/faq" title="small Lottery Frequently Asked Questions">Frequently Asked Questions</a> page to learn more about the site and how it works before you sign up.</p>
                
                <p>If you didn't receive your verification email, you may need to add small-Lottery.net to your <a href="/how-to-add-a-safe-sender" title="Adding small Lottery as a safe sender for your email account">Safe Sender</a> list. This will stop any notifications from us mistakenly being sent you your junk email folder.</p>
			</section>

			<section>
				<h2>The Games</h2>
				<p>Draws are available to any person who has registered with the site and verified their details. There are two games on offer - the Daily Draw worth &pound;500 and the Weekly Draw worth &pound;10,000. On signing up, you'll get the chance to play in the next available Weekly Draw, but after that you will need to play the Daily Draw at least three times in a calendar week to qualify for the Weekly Draw again.</p>
			
				
			</section>

			<section>
				<h2>Picking Your Numbers</h2>
				<p>If you've finished setting up your account and verifying your details, you can start playing small Lottery games straight away. There are two ways to enter; you can pick your numbers on your own if you wish, or have them randomly generated for you using the Quick Pick option. If you're an analytical type, you can check out the <a title="small Lottery Statistics" href="/statistics">small Lottery Statistics</a> page, which provides information about which numbers have been drawn most frequently, those which are picked the least, which numbers are most overdue and more.</p>
			</section>

			<section>
				<h2>Results</h2>
				<p>Whether you came up with your numbers on your own or relied on the Quick Pick option to generate your ticket, you can always find out about how well you did by visiting the <a href="/latest-results" title="Latest small Lottery Results">Latest Results</a> page.</p>
			
			</section>

			<section>
				<h2>Claiming a Prize</h2>
				<p>If you've checked the results and think you've won a small Lottery prize, you can start the claims procedure by getting in touch with the small Lottery team through the <a href="/contact" title="Contact small Lottery">Contact Us</a> page<sup>*</sup>.</p>
                
                <p>In the event that you are contacted by someone who you believe isn't part of the small Lottery team about a win or your account, visit the <a href="/scams" title="How to identify lottery scams">Scams</a> page for tips on how to protect yourself.</p>
			</section>

			<section>
				<h2>Anything Else?</h2>
				<p>If you're still having issues and can't find an answer here or on any other page of small-Lottery.net, then feel small to get in touch by using the <a href="/contact" title="Contact small Lottery">Contact Us</a> page.</p>
			</section>
            
            <p align="center">
        <sub>*Prizes must be claimed within 2 working days of the winning draw. If no one matches all six numbers in a Daily Draw or Weekly Draw, no prize will be awarded for that draw. See <a href="/terms-and-conditions" title="small Lottery T&Cs">Terms & Condtions</a> for the full small Lottery rules.</sub></p>  

		</div>

	</article>
	</div>
