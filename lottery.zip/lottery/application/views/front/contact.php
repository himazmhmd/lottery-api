<div class="breadcrumbs">
	<div class="container">
		<ol class="breadcrumb" itemscope itemtype="http://schema.org/BreadcrumbList">
		
		    <li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="1">
		        <a href="<?php echo base_url()?>" title=" Home" itemprop="item">
		        	<span itemprop="name">SmallLottery.com Home</span>
		        </a>
		    </li>
		    
            	<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
            		<meta itemprop="position" content="2">
		    		<a href="<?php echo base_url('help');?>" title="Small Lottery Help and Information" itemprop="item"><span itemprop="name" style="display: inline-block;">Help</span></a>
		    	</li>
		    
		    	<li>contact </li>
            
            
		</ol>
	</div>
</div>
<div class="container contact-page">

	<article>

		

		<header class="featured-text">

			<h1>Contact Us</h1>

			<p>If you would like to claim a prize, send feedback about Small Lottery or if you have any issues or concerns, please get in touch.</p>
			<hr>

		</header>

		<div class="main">

			<section class="generic-box">

				<h2>Contact Options</h2>

				<div class="first-elem">
					<div class="title">Email Address</div>

				<?php echo $this->crud_model->get_email(); ?>

					<div class="title">Social Media</div>

					<ul class="social">
						<li><a href="https://web.facebook.com/groups/743456646530230/?_rdc=1&_rdr" target=_blank title="Follow Small Lottery on Facebook">Facebook</a></li>
					
					</ul>
				</div>

				<div class="second-elem">

					<div class="title">Postal Address</div>

					<ul>
						<li>smalllottery.com</li>
						<li>The Exchange</li>
						<li>Station Parade</li>
						<li>Harrogate</li>
						<li>HG1 1TS</li>
					</ul>

				</div>

				

			</section>

		</div>


		


	</article>

	

    </div>