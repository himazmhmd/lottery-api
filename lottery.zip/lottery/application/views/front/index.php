<div id="quickPick">

	<div class="container">

		<div class="main ticket">

			<div class="select-numbers no-bp">

				<div class="lower">

					<div class="row-1">

						<h2>Choose six numbers from the grid below to start playing</span></h2>

						<div class="row-2" style="display: block;">

							<p class="title" id="remainingBalls" style="display: none;">Please Choose <strong>6</strong> Numbers</p>

							<script type="text/javascript">
								function validateTicket() {
									var cookieString = "";
									for (i = 1; i <= 6; i++) {
										if (document.getElementById("B0_" + i).value == '') {

											alert("Please select six numbers.");
											return false;
										}
										cookieString += document.getElementById("B0_" + i).value
										if (i < 6) cookieString += "|";

									}

									/* $('#submit_ticket').fadeOut(500);
									$('#signUp').fadeIn(1000, function() {
										$('#FirstName').focus();
									}); */
									window.location.href = "<?php echo base_url('home/playgame'); ?>";
									var cookieExpire = new Date();
									cookieExpire.setDate(cookieExpire.getDate() + 28);
									document.cookie = 'WeeklyNumbers' + "=" + cookieString + "; expires=" + cookieExpire.toUTCString() + "; path=/;";

									return false;
								};
							</script>

							<form method="post" name="form_play" id="form_play" onSubmit="return validateTicket()">
								<div class="middle">


									<input name="B0_1" id="B0_1" type="hidden" />
									<input name="B0_2" id="B0_2" type="hidden" />
									<input name="B0_3" id="B0_3" type="hidden" />
									<input name="B0_4" id="B0_4" type="hidden" />
									<input name="B0_5" id="B0_5" type="hidden" />
									<input name="B0_6" id="B0_6" type="hidden" />


									<a href="javascript:;" id="B0ID_1" onClick="javascript:P('1','0');" class="ball" title="1">1</a>



									<a href="javascript:;" id="B0ID_2" onClick="javascript:P('2','0');" class="ball" title="2">2</a>



									<a href="javascript:;" id="B0ID_3" onClick="javascript:P('3','0');" class="ball" title="3">3</a>



									<a href="javascript:;" id="B0ID_4" onClick="javascript:P('4','0');" class="ball" title="4">4</a>



									<a href="javascript:;" id="B0ID_5" onClick="javascript:P('5','0');" class="ball" title="5">5</a>



									<a href="javascript:;" id="B0ID_6" onClick="javascript:P('6','0');" class="ball" title="6">6</a>



									<a href="javascript:;" id="B0ID_7" onClick="javascript:P('7','0');" class="ball" title="7">7</a>



									<a href="javascript:;" id="B0ID_8" onClick="javascript:P('8','0');" class="ball" title="8">8</a>



									<a href="javascript:;" id="B0ID_9" onClick="javascript:P('9','0');" class="ball" title="9">9</a>



									<a href="javascript:;" id="B0ID_10" onClick="javascript:P('10','0');" class="ball" title="10">10</a>



									<a href="javascript:;" id="B0ID_11" onClick="javascript:P('11','0');" class="ball" title="11">11</a>



									<a href="javascript:;" id="B0ID_12" onClick="javascript:P('12','0');" class="ball" title="12">12</a>



									<a href="javascript:;" id="B0ID_13" onClick="javascript:P('13','0');" class="ball" title="13">13</a>



									<a href="javascript:;" id="B0ID_14" onClick="javascript:P('14','0');" class="ball" title="14">14</a>



									<a href="javascript:;" id="B0ID_15" onClick="javascript:P('15','0');" class="ball" title="15">15</a>



									<a href="javascript:;" id="B0ID_16" onClick="javascript:P('16','0');" class="ball" title="16">16</a>



									<a href="javascript:;" id="B0ID_17" onClick="javascript:P('17','0');" class="ball" title="17">17</a>



									<a href="javascript:;" id="B0ID_18" onClick="javascript:P('18','0');" class="ball" title="18">18</a>



									<a href="javascript:;" id="B0ID_19" onClick="javascript:P('19','0');" class="ball" title="19">19</a>



									<a href="javascript:;" id="B0ID_20" onClick="javascript:P('20','0');" class="ball" title="20">20</a>



									<a href="javascript:;" id="B0ID_21" onClick="javascript:P('21','0');" class="ball" title="21">21</a>



									<a href="javascript:;" id="B0ID_22" onClick="javascript:P('22','0');" class="ball" title="22">22</a>



									<a href="javascript:;" id="B0ID_23" onClick="javascript:P('23','0');" class="ball" title="23">23</a>



									<a href="javascript:;" id="B0ID_24" onClick="javascript:P('24','0');" class="ball" title="24">24</a>



									<a href="javascript:;" id="B0ID_25" onClick="javascript:P('25','0');" class="ball" title="25">25</a>



									<a href="javascript:;" id="B0ID_26" onClick="javascript:P('26','0');" class="ball" title="26">26</a>



									<a href="javascript:;" id="B0ID_27" onClick="javascript:P('27','0');" class="ball" title="27">27</a>



									<a href="javascript:;" id="B0ID_28" onClick="javascript:P('28','0');" class="ball" title="28">28</a>



									<a href="javascript:;" id="B0ID_29" onClick="javascript:P('29','0');" class="ball" title="29">29</a>



									<a href="javascript:;" id="B0ID_30" onClick="javascript:P('30','0');" class="ball" title="30">30</a>



									<a href="javascript:;" id="B0ID_31" onClick="javascript:P('31','0');" class="ball" title="31">31</a>



									<a href="javascript:;" id="B0ID_32" onClick="javascript:P('32','0');" class="ball" title="32">32</a>



									<a href="javascript:;" id="B0ID_33" onClick="javascript:P('33','0');" class="ball" title="33">33</a>



									<a href="javascript:;" id="B0ID_34" onClick="javascript:P('34','0');" class="ball" title="34">34</a>



									<a href="javascript:;" id="B0ID_35" onClick="javascript:P('35','0');" class="ball" title="35">35</a>



									<a href="javascript:;" id="B0ID_36" onClick="javascript:P('36','0');" class="ball" title="36">36</a>



									<a href="javascript:;" id="B0ID_37" onClick="javascript:P('37','0');" class="ball" title="37">37</a>



									<a href="javascript:;" id="B0ID_38" onClick="javascript:P('38','0');" class="ball" title="38">38</a>



									<a href="javascript:;" id="B0ID_39" onClick="javascript:P('39','0');" class="ball" title="39">39</a>



									<a href="javascript:;" id="B0ID_40" onClick="javascript:P('40','0');" class="ball" title="40">40</a>



									<a href="javascript:;" id="B0ID_41" onClick="javascript:P('41','0');" class="ball" title="41">41</a>



									<a href="javascript:;" id="B0ID_42" onClick="javascript:P('42','0');" class="ball" title="42">42</a>



									<a href="javascript:;" id="B0ID_43" onClick="javascript:P('43','0');" class="ball" title="43">43</a>



									<a href="javascript:;" id="B0ID_44" onClick="javascript:P('44','0');" class="ball" title="44">44</a>



									<a href="javascript:;" id="B0ID_45" onClick="javascript:P('45','0');" class="ball" title="45">45</a>



									<a href="javascript:;" id="B0ID_46" onClick="javascript:P('46','0');" class="ball" title="46">46</a>



									<a href="javascript:;" id="B0ID_47" onClick="javascript:P('47','0');" class="ball" title="47">47</a>



									<a href="javascript:;" id="B0ID_48" onClick="javascript:P('48','0');" class="ball" title="48">48</a>



									<a href="javascript:;" id="B0ID_49" onClick="javascript:P('49','0');" class="ball" title="49">49</a>



									<a href="javascript:;" id="B0ID_50" onClick="javascript:P('50','0');" class="ball" title="50">50</a>



									<a href="javascript:;" id="B0ID_51" onClick="javascript:P('51','0');" class="ball" title="51">51</a>



									<a href="javascript:;" id="B0ID_52" onClick="javascript:P('52','0');" class="ball" title="52">52</a>



									<a href="javascript:;" id="B0ID_53" onClick="javascript:P('53','0');" class="ball" title="53">53</a>



									<a href="javascript:;" id="B0ID_54" onClick="javascript:P('54','0');" class="ball" title="54">54</a>



									<a href="javascript:;" id="B0ID_55" onClick="javascript:P('55','0');" class="ball" title="55">55</a>



									<a href="javascript:;" id="B0ID_56" onClick="javascript:P('56','0');" class="ball" title="56">56</a>



									<a href="javascript:;" id="B0ID_57" onClick="javascript:P('57','0');" class="ball" title="57">57</a>



									<a href="javascript:;" id="B0ID_58" onClick="javascript:P('58','0');" class="ball" title="58">58</a>



									<a href="javascript:;" id="B0ID_59" onClick="javascript:P('59','0');" class="ball" title="59">59</a>



									<a href="javascript:;" id="B0ID_60" onClick="javascript:P('60','0');" class="ball" title="60">60</a>



									<a href="javascript:;" id="B0ID_61" onClick="javascript:P('61','0');" class="ball" title="61">61</a>



									<a href="javascript:;" id="B0ID_62" onClick="javascript:P('62','0');" class="ball" title="62">62</a>



									<a href="javascript:;" id="B0ID_63" onClick="javascript:P('63','0');" class="ball" title="63">63</a>



									<a href="javascript:;" id="B0ID_64" onClick="javascript:P('64','0');" class="ball" title="64">64</a>



									<a href="javascript:;" id="B0ID_65" onClick="javascript:P('65','0');" class="ball" title="65">65</a>



									<a href="javascript:;" id="B0ID_66" onClick="javascript:P('66','0');" class="ball" title="66">66</a>



									<a href="javascript:;" id="B0ID_67" onClick="javascript:P('67','0');" class="ball" title="67">67</a>



									<a href="javascript:;" id="B0ID_68" onClick="javascript:P('68','0');" class="ball" title="68">68</a>



									<a href="javascript:;" id="B0ID_69" onClick="javascript:P('69','0');" class="ball" title="69">69</a>



									<a href="javascript:;" id="B0ID_70" onClick="javascript:P('70','0');" class="ball" title="70">70</a>



									<a href="javascript:;" id="B0ID_71" onClick="javascript:P('71','0');" class="ball" title="71">71</a>



									<a href="javascript:;" id="B0ID_72" onClick="javascript:P('72','0');" class="ball" title="72">72</a>



									<a href="javascript:;" id="B0ID_73" onClick="javascript:P('73','0');" class="ball" title="73">73</a>



									<a href="javascript:;" id="B0ID_74" onClick="javascript:P('74','0');" class="ball" title="74">74</a>



									<a href="javascript:;" id="B0ID_75" onClick="javascript:P('75','0');" class="ball" title="75">75</a>



									<br class="clear" />
									<a href="javascript:;" class="btn" onClick="animatedRandomBalls();" title="Quick Pick">Quick Pick</a>
									<input type="button" name="reset_ticket" id="reset_ticket" class="btn" onClick="ResetForm(); $('#submit_ticket').fadeIn(500); $('#signUp').fadeOut(500);" value="Reset" />

								</div>
								<a id="scroll_point"></a>
								<div class="bottom">
									<div class="title">Your Small Lottery Numbers</div>
									<ul>
										<li id="empty01"></li>
										<li id="empty02"></li>
										<li id="empty03"></li>
										<li id="empty04"></li>
										<li id="empty05"></li>
										<li id="empty06"></li>
									</ul>
									<input name="submit_ticket" id="submit_ticket" type="submit" value="Play Now" class="btn" style="font-size: 24px;" />

								</div>

							</form>

						</div>


					</div>

				</div>

			</div>

		</div>
		<div class="star">

		</div>

		<div id="signUp">

			<h2><span style="color: #FFF; font-weight: normal;">Enter your details to validate your entry:</span></h2>



			<script type="text/javascript">
				function checkForm() {
					if (document.getElementById("FirstName").value == "") {
						alert("Please enter your first name.");
						document.getElementById("FirstName").focus();
						return false;
					}

					if (document.getElementById("Surname").value == "") {
						alert("Please enter your surname.");
						document.getElementById("Surname").focus();
						return false;
					}

					if (document.getElementById("Email").value == "") {
						alert("Please enter your email address.");
						document.getElementById("Email").focus();
						return false;
					} else {
						apos = document.getElementById("Email").value.indexOf("@");
						dotpos = document.getElementById("Email").value.lastIndexOf(".");

						if (apos < 1 || dotpos - apos < 2) {
							alert("Please enter a valid email address.");
							document.getElementById("Email").focus();
							return false;
						}
					}

					if (document.getElementById("Password").value == "") {
						alert("Please enter a password.");
						document.getElementById("Password").focus();
						return false;
					}

					if (document.getElementById("ConfirmPassword").value == "") {
						alert("Please confirm your password.");
						document.getElementById("ConfirmPassword").focus();
						return false;
					} else {
						if (document.getElementById("Password").value != document.getElementById("ConfirmPassword").value) {
							alert("Your passwords do not match.");
							document.getElementById("Password").focus();
							return false;
						}
					}

					if (!document.getElementById("AcceptTerms").checked) {
						alert("Please read and accept the terms & conditions.");
						return false;
					}



					return true;
				}
			</script>

			<form action="<?= base_url('playgame'); ?>" id="form" name="form" method="post" onSubmit="return checkForm();">

				<label for="FirstName">First Name <span class="alert">*</span></label>
				<input id="FirstName" name="FirstName" class="form-control forminput resizedTextbox" tabindex="3" type="text" maxlength="255" value="" />
				<br>
				<input name="weeklynumbers" type="hidden" value="<?php
																	if (isset($_COOKIE["WeeklyNumbers"])) {
																		echo $_COOKIE["WeeklyNumbers"];
																	}


																	?>" />
				<label for="Surname">Surname <span class="alert">*</span></label>
				<input id="Surname" name="Surname" class="form-control forminput resizedTextbox" tabindex="4" type="text" maxlength="255" value="" />
				<br>

				<label for="Email">Email Address <span class="alert">*</span></label>
				<input id="Email" name="Email" class="form-control forminput resizedTextbox" tabindex="5" type="email" maxlength="255" value="" />
				<br>

				<label for="Password">Password <span class="alert">*</span></label>
				<input id="Password" name="Password" class="form-control forminput resizedTextbox" tabindex="6" type="password" maxlength="255" />
				<br>

				<label for="ConfirmPassword">Confirm Password <span class="alert">*</span></label>
				<input id="ConfirmPassword" name="ConfirmPassword" class="form-control forminput resizedTextbox" tabindex="7" type="password" maxlength="255" />
				<br>



				<label for="AcceptTerms">I accept the <a href="terms-and-conditions.html" target="_blank" title="Click here to read the terms and conditions" style="color: #FF0;">Terms &amp; Conditions</a><span class="alert">*</span></label>
				<input type="checkbox" id="AcceptTerms" name="AcceptTerms" value="1" tabindex="9" />

				<br class="clear"><br>

				<input id="Submit" class="submit-btn" name="playn" type="submit" tabindex="10" value="Register &amp; Play" style="float: left; width: auto;" />
				<input id="Register" name="Register" type="hidden" value="1" />

				<p style="float: right;">
					<span style="color: #FFF;">Already registered?</span><br>
					<a href="<?= base_url('login'); ?>" title="Click here to login to your exising Small Lottery account">Click here to Login</a>
				</p>

			</form>

			<br class="clear">
			<p><strong><span class="alert">*</span></strong> Indicates required fields</p>



		</div>

	</div>

</div>