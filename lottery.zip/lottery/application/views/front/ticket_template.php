<div class="game">
	<div style="float:left; width:36%;overflow:hidden;">
		<div style="font-family: Courier, san-serif; color:#000; background:#6BB64A; padding:10px; overflow:hidden; width:270px; height:300px; position:relative;">
			<img src="<?= base_url('assets') ?>/images/template/tic2.png" alt="Daily Draw Logo" style="margin-right:10px!important;}" />
				<?php foreach ($this->data as $row) {
				$name = $this->db->get_where('packages', array('id' => $row['package_id']))->row()->title;
				?>
		       <h3 style="text-align:right"> 	<?= $name; ?></h3>
			<div style="width:100%;
    border-bottom:2px dashed #000;
    clear:both;
    overflow:hidden;
    padding-bottom:10px; margin:0 0 10px; float:left;
    ">
				<div style="float:left;">Your Numbers</div>


			</div>
		
				<div class="ticket-body">
					<ul style="width:90%; clear:both; font-size:15px; border-bottom:2px dashed #000; overflow:hidden; margin-left:-50px;padding-bottom:5px; list-style-type: none; margin-bottom:5px">
					    		

						<li style="float:left;height:30px; width:25px; text-align:center; line-height:38px;"><?= $row['BO_1']; ?></li>
						<li style="float:left;height:30px; width:25px; text-align:center; line-height:38px;"><?= $row['BO_2']; ?></li>
						<li style="float:left;height:30px; width:25px; text-align:center; line-height:38px;"><?= $row['BO_3']; ?></li>
						<li style="float:left;height:30px; width:25px; text-align:center; line-height:38px;"><?= $row['BO_4']; ?></li>
						<li style="float:left;height:30px; width:25px; text-align:center; line-height:38px;"><?= $row['BO_5']; ?></li>
						<li style="float:left;height:30px; width:25px; text-align:center; line-height:38px;"><?= $row['BO_6']; ?></li>
					</ul>
				</div>
			<?php } ?>
			<div style="width:65%;  text-align:center;">Good Luck!</div>
			<canvas id="barcodeDaily"></canvas>

		</div>
	</div>
	
</div>