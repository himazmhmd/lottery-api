<head>
    <link href="<?= base_url('assets'); ?>/css/style327b.css?v=201906271349" rel="stylesheet">
    <script type="text/javascript" src="<?= base_url('assets'); ?>/js/jquery.js"></script>

</head>
<div class="game">
    <div class="first-col">
        <div class="ticket-box">
            <img src="<?= base_url('assets') ?>/images/template/logo.png" alt="Daily Draw Logo" class="ticket-logo" />

            <div class="ticket-head">
                <div class="title">Your Numbers</div>

            </div>
            <?php foreach ($this->data as $row) { ?>
                <div class="ticket-body">
                    <ul class="numbers">
                        <li><?= $row['BO_1']; ?></li>
                        <li><?= $row['BO_2']; ?></li>
                        <li><?= $row['BO_3']; ?></li>
                        <li><?= $row['BO_4']; ?></li>
                        <li><?= $row['BO_5']; ?></li>
                        <li><?= $row['BO_6']; ?></li>
                    </ul>
                </div>
            <?php } ?>
            <div class="prize-m">Good Luck!</div>
            <canvas id="barcodeDaily"></canvas>

        </div>
    </div>
    <script type="text/javascript" src="<?= base_url('assets') ?>/js/barcode.js"></script>
    <script type="text/javascript">
        $('#barcodeDaily').JsBarcode('248455774', {
            width: 1,
            height: 20,
            quite: 60,
            format: "CODE128",
            displayValue: true,
            font: "monospace",
            textAlign: "center",
            fontSize: 12,
            backgroundColor: "",
            lineColor: "#000"
        });
    </script>
</div>