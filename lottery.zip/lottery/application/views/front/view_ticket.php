<div class="container register">
  
    <div class="register-content">

    <h1 class="big-text">Click On View button <br><span>to get ticket on your </span> Email!</h1>

        <form action="<?= base_url('home/ticket_generate'); ?>" id="form" name="form" method="post" onSubmit="return checkForm();">


            <div class="fifty-percent pull-left">
                <input name="weeklynumbers" type="hidden" value="<?php
                                                                    if (isset($_COOKIE["WeeklyNumbers"])) {
                                                                        echo $_COOKIE["WeeklyNumbers"];
                                                                    }
                                                                    ?>" />
<input type="hidden" name="user_id" value="<?= $this->session->userdata('user_id') ?>"/>

<input type="hidden" name="package_id" value="<?= $package; ?>"/>
<input id="Submit" class="submit-btn" name="btn3" type="submit"  value="View" />
            </div>


        </form>

    </div>
</div>