<!-- <div class="breadcrumbs">
	<div class="container">
		<ol class="breadcrumb" itemscope itemtype="http://schema.org/BreadcrumbList">

			<li itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
				<meta itemprop="position" content="1">
				<a href="<?php echo base_url(); ?>" title="small lottery Home" itemprop="item">
					<span itemprop="name">Home</span>
				</a>
			</li>


			<li>register </li>


		</ol>
	</div>
</div> -->
<div class="container register">

	<div class="register-content">
		<script type="text/javascript">
			function checkForm() {
				if (document.getElementById("FirstName").value == "") {
					alert("Please enter your first name.");
					document.getElementById("FirstName").focus();
					return false;
				}

				if (document.getElementById("Surname").value == "") {
					alert("Please enter your surname.");
					document.getElementById("Surname").focus();
					return false;
				}

				if (document.getElementById("Email").value == "") {
					alert("Please enter your email address.");
					document.getElementById("Email").focus();
					return false;
				} else {
					apos = document.getElementById("Email").value.indexOf("@");
					dotpos = document.getElementById("Email").value.lastIndexOf(".");

					if (apos < 1 || dotpos - apos < 2) {
						alert("Please enter a valid email address.");
						document.getElementById("Email").focus();
						return false;
					}
				}

				if (document.getElementById("Password").value == "") {
					alert("Please enter a password.");
					document.getElementById("Password").focus();
					return false;
				}

				if (document.getElementById("ConfirmPassword").value == "") {
					alert("Please confirm your password.");
					document.getElementById("ConfirmPassword").focus();
					return false;
				} else {
					if (document.getElementById("Password").value != document.getElementById("ConfirmPassword").value) {
						alert("Your passwords do not match.");
						document.getElementById("Password").focus();
						return false;
					}
				}

				if (!document.getElementById("AcceptTerms").checked) {
					alert("Please read and accept the terms & conditions.");
					return false;
				}
				if (document.getElementById("card_number").value == "") {
					alert("Please enter your Card Number.");
					document.getElementById("card_number").focus();
					return false;
				}
				if (document.getElementById("exp_month").value == "") {
					alert("Please enter your Card  Exp Month.");
					document.getElementById("exp_month").focus();
					return false;
				}

				if (document.getElementById("exp_year").value == "") {
					alert("Please enter your Card  Exp year.");
					document.getElementById("exp_year").focus();
					return false;
				}
				if (document.getElementById("cvv").value == "") {
					alert("Please enter your Card Cvv.");
					document.getElementById("cvv").focus();
					return false;
				}


				return true;
			}
		</script>
		<?php if ($this->session->flashdata('success')) { ?>
			<h3 class="alert alert-success" >
				<?php echo $this->session->flashdata('success'); ?>
			</h3>
		<?php } ?>
		<?php if ($this->session->flashdata('error')) { ?>
			<h3 class="alert alert-warning" >
				<?php echo $this->session->flashdata('error'); ?>
			</h3>
		<?php } ?>
		<h2>Enter your details to register</h2>

		<form action="<?= base_url('register'); ?>" id="form" name="form" method="post" onSubmit="return checkForm();">


			<div class="fifty-percent pull-left">
				<input name="weeklynumbers" type="hidden" value="<?php
																	if (isset($_COOKIE["WeeklyNumbers"])) {
																		echo $_COOKIE["WeeklyNumbers"];
																	}


																	?>" />

				<label for="FirstName">First Name <span class="alert">*</span></label>
				<input id="FirstName" name="FirstName" class="form-control forminput resizedTextbox" tabindex="3" type="text" maxlength="255" value="" required  />


				<label for="Surname">Surname <span class="alert">*</span></label>
				<input id="Surname" name="Surname" class="form-control forminput resizedTextbox" tabindex="4" type="text" maxlength="255" value="" />


				<label for="Email">Email Address <span class="alert">*</span></label>
				<input id="Email" name="Email" class="form-control forminput resizedTextbox" tabindex="5" type="email" maxlength="255" value="" />
				<label for="Password">Password <span class="alert">*</span></label>
				<input id="Password" name="Password" class="form-control forminput resizedTextbox" tabindex="6" type="password" maxlength="255" />


				<label for="ConfirmPassword">Confirm Password <span class="alert">*</span></label>
				<input id="ConfirmPassword" name="ConfirmPassword" class="form-control forminput resizedTextbox" tabindex="7" type="password" maxlength="255" />
			</div>
			<div class="fifty-percent pull-right">

			<label for="FirstName">Account Number<span class="alert">*</span></label>
				<input id="FirstName" name="card_number" class="form-control forminput resizedTextbox" tabindex="7" type="text" maxlength="255" value="" required />
				<label for="FirstName">IFSC / swift code<span class="alert">*</span></label>
				<input id="FirstName" name="exp_month" class="form-control forminput resizedTextbox" tabindex="8" type="text" maxlength="255" value=""  required/>
			
				


				<label for="AcceptTerms">I accept the <a href="<?= base_url('term') ?>" target="_blank" title="Click here to read the terms and conditions">Terms &amp; Conditions</a><span class="alert">*</span></label>
				<input type="checkbox" id="AcceptTerms" name="AcceptTerms" value="1" tabindex="11" />
				<br><br>


				<input id="Submit" class="submit-btn" name="playn" type="submit" tabindex="10" value="Register" />
				<input id="Register" name="Register" type="hidden" value="1" />

			</div>

		</form>

		<div class="clear"></div>
		<p class="pull-left"><strong><span class="alert">*</span></strong> Indicates required fields</p>



	</div>


	<!-- <div class="register-jackpot">
		<div class="jackpot-amount">&pound;10,000!</div>

		<div class="counters" id="Counter11">
			<span></span><span></span><span></span><span></span>
		</div>

		<script type="text/javascript">
			var daysCounter11 = 4;
			var hoursCounter11 = 1;
			var minutesCounter11 = 47;
			var secondsCounter11 = 24;
			var countdownCounter11 = "";

			function displayCounter11() {

				if (daysCounter11 > 0 || hoursCounter11 > 0 || minutesCounter11 > 0 || secondsCounter11 > 0) {

					if (hoursCounter11 <= 0 && minutesCounter11 <= 0 && secondsCounter11 <= 0) {
						hoursCounter11 = 23;
						minutesCounter11 = 59;
						secondsCounter11 = 59;
						daysCounter11 -= 1
					} else if (minutesCounter11 <= 0 && secondsCounter11 <= 0) {
						minutesCounter11 = 59;
						secondsCounter11 = 59;
						hoursCounter11 -= 1
					} else if (secondsCounter11 <= 0) {
						secondsCounter11 = 59;
						minutesCounter11 -= 1
					} else {
						secondsCounter11 -= 1
					};




					countdownCounter11 = "<div class=\"title\">Time Left to Play:</div>";
					countdownCounter11 += "<ul>";
					countdownCounter11 += "<li>" + daysCounter11 + "<span>Days</span></li>";
					countdownCounter11 += "<li>" + hoursCounter11 + "<span>Hours</span></li>";

					countdownCounter11 += "<li>" + minutesCounter11 + "<span>Mins</span></li>";
					countdownCounter11 += "<li>" + secondsCounter11 + "<span>Secs</span></li>";
					countdownCounter11 += "</ul>";

					document.getElementById("Counter11").innerHTML = countdownCounter11;

					setTimeout("displayCounter11()", 1000);

					//} else {window.location.reload();}
				}
			};

			displayCounter11();
		</script>

		<div class="call-to-act">What are you waiting for?</div>
	</div> -->

</div>