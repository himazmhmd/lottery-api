<div class="container account-settings">
    <h1>Account Settings</h1>
 
 <div class="main">

        <div class="generic-box-half no-lm">

            <h2>Personal Details</h2>

            <div class="account-box">

                <img src="<?php echo base_url('assets') ?>/images/template/display-icon.png" alt="Display Icon" />

                <div class="title">Display Name</div>

                <p><?= $user['username'];?></p>

            </div>

            <div class="account-box">

                <img src="<?php echo base_url('assets') ?>/images/template/name-icon.png" alt="Book Icon" />

                <div class="title">First Name</div>

                <p><?= $user['firstname'];?></p>

            </div>
            <div class="account-box">

                <img src="<?php echo base_url('assets') ?>/images/template/name-icon.png" alt="Book Icon" />

                <div class="title">Card Number</div>

                <p><?= $user['card_number'];?></p>

            </div>
            <a class="edit-icon-small" href="<?php echo base_url('change_password/')?>" title="Change your password" style="background-image: none; padding-left: 10px;">Change Password</a>
            <a class="edit-icon-small" href="<?php echo base_url('edit_settings/')?>" title="Edit your personal details" style="margin: 0 3px; padding-left: 40px;">Edit</a>

        </div>

        <div class="generic-box-half">

            <h2>Communication Preferences</h2>

            <div class="account-box">

                <img src="<?php echo base_url('assets') ?>/images/template/email-icon.png" alt="Email Icon" />

                <div class="title">Your Email Address</div>

                <p class="no-bm"><?= $user['email'];?></p>


            </div>

            <div class="account-box">

                <img src="<?php echo base_url('assets') ?>/images/template/phone-icon.png" alt="Phone Icon" />

                <div class="title">Mobile Number</div>
                <?php if($user['mobile_no']==''){?>
                    <p class="no-bm"> Please add your mobile numberSo we can contact you if you win a price. click on edit button to add your Mobile Number</p>
              <?php }else{?>
                    <p class="no-bm"><?= $user['mobile_no'];?></p>
                 <?php }?>
              
               



            </div>



        </div>





    </div>

</div>