
<div class="container account-settings">

    <div class="main">
	<?php if ($this->session->flashdata('success')) { ?>
			<h3 class="alert-success" >
				<?php echo $this->session->flashdata('success'); ?>
			</h3>
		<?php } ?>
		<?php if ($this->session->flashdata('error')) { ?>
			<h3 class="alert-warning" >
				<?php echo $this->session->flashdata('error'); ?>
			</h3>
		<?php } ?>
        <div class="generic-box">
            <h2>Change Personal Details</h2>
            <p>Please note: Your full name and Card Number are required for prize payments. Valid ID documents, matching these details, will be required when you make a claim.</p>
            <form id="form" name="form" action="<?= base_url('home/update_setting/').$user['id'] ?>" method="post">

                <div class="fifty-percent pull-left">

                   
                    <label for="">User Name<span class="alert">*</span></label>
                    <input id="" name="username" type="text" size="30" maxlength="255" value="<?= $user['username'] ?>" placeholder="" class="form-control" required  />
                
                    <label for="City">First Name<span class="alert">*</span></label>
                    <input id="City" name="firstname" type="text" size="30" maxlength="255" value="<?= $user['firstname'] ?>" placeholder="" class="form-control" required  />


                    <label for="County">Surname<span class="alert">*</span></label>
                    <input id="County" name="surname" type="text" size="30" maxlength="255" value="<?= $user['lastname'] ?>" placeholder="" class="form-control" required  />


                   
                    <label for="FriendlyName">Email</label>
                    <input id="Surname" name="email" type="email" size="30" maxlength="255" class="form-control" value="<?= $user['email'] ?>" placeholder="" required />

                    <label for="FriendlyName">Mobile Number</label>
                    <input id="Surname" name="mobile_number" type="text" size="30" maxlength="255" class="form-control" value="<?= $user['mobile_no'] ?>" placeholder="Enter Your Mobile Number" required />

                </div>

                <div class="fifty-percent pull-right">

                <label for="City">Account Number<span class="alert">*</span></label>
                    <input id="City" name="card_number" type="text" size="30" maxlength="255" value="<?= $user['card_number'] ?>" placeholder="" class="form-control" required  />
                
                    <label for="City">IFSC / swift code<span class="alert">*</span></label>
                    <input id="City" name="exp_month" type="text" size="30" maxlength="255" value="<?= $user['exp_month'] ?>" placeholder="" class="form-control" required  />


                    
                    <label for="FriendlyName">Country</label>
                    <input id="Surname" name="country" type="text" size="30" maxlength="255" class="form-control" value="<?= $user['country'] ?>" placeholder="Enter Your country" required />
                    <!-- <label for="FriendlyName">Address</label>
                    <input id="Surname" name="address" type="text" size="30"  class="form-control" value="" placeholder="" /> -->
                    <input id="Submit" type="submit" value="Update" name="btn1" class="btn" />

                   
                </div>
            </form>

            <div class="bottom-text"><span class="alert">*</span>Indicates required fields</div>

        </div>


    </div>
</div>