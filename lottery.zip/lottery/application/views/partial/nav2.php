<div class="navinner-wrapper">

	<div class="container">

	<?php $logo= $this->crud_model->setting();?>
		<div class="logo"><a href="<?= base_url(); ?>" title="smalllottery"><img src="<?php echo base_url('/').$logo ?>" alt="Free Lottery Logo"></a></div>

		<div class="navbar">



			<ul class="nav nav-inner">

				<li class="active"><a href="<?= base_url(); ?>" title="smalllottery">Home</a></li>

			
				<li class=" results">
					<div class="dropdown">
						<div><a href="<?= base_url('home/plans') ?>" title="Latest Samll Lottery Plans">Plans</a></div>
					</div>
				</li>
				<li>
					<div class="dropdown">
						<a href="<?= base_url('contact') ?>" title="Help and Support" class="dropbtn">Contact Us</a>
						
					</div>
				</li>

				<li class=" winners">
					<div class="dropdown">
						<a href="<?= base_url('winners') ?>" title="Previous Winners" class="dropbtn">Winners</a>
						
					</div>
				</li>
				<?php if(!$this->session->has_userdata('user_id')) { ?>
				<li class="active"><a href="<?= base_url('register') ?>" title="More Online Lottery Games">Create Accont</a></li>
				<li class="active"><a href="<?= base_url('login') ?>" title="create account">Login</a></li>

               <?php  }else{?>
  
				<li class="active"><a href="<?= base_url('home/dashboard') ?>" title="Dashboard">Dashboard</a></li>
				<li class="active"><a href="<?= base_url('home/logout') ?>" title="Logout">Logout</a></li>
                <?php } ?>
			</ul>
		</div>
		<?php if($this->session->has_userdata('user_id')) { ?>
		<div class="profile-menu">
			<div class="inner">
				
				<div class="friendly-name ">
					Hello <span><?= ucwords($this->session->userdata('username')); ?></span>
				</div>
			

				<div class="settings">
					<span title="Change your settings"></span>
					<ul>
						<li><a href="<?= base_url('home/acc_setting'); ?>" title="Account Settings">Account Setting</a></li>

					</ul>
				</div>
			</div>
		</div>
<?php } ?>

	</div>



</div>