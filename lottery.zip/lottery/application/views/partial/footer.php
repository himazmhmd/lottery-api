<div class="featured-3-footer">
	<div class="container">
		<div class="featured-text">
			<blockquote>"Join us on social media to keep up <br>with the latest promotions!"</blockquote>
		</div>
		<div class="socialMediaIcons">
			
			<a href="https://web.facebook.com/groups/743456646530230/?_rdc=1&_rdr" title="Follow Small Lottery on Facebook" target="_blank"><img src="<?= base_url('assets');?>/images/template/facebook.png" alt="Like Us on Twitter" /></a
		</div>
	</div>
</div>


<script>
smoothScroll.init({
    speed: 800,
    easing: 'easeInOutQuad',
    updateURL: false,
    offset: 0,
    callbackBefore: function ( toggle, anchor ) {},
    callbackAfter: function ( toggle, anchor ) {}
});
</script>
<div class="footer">

	<p class="small-section"><strong>All Content and Material Copyright &copy; 2021 SmallLottery</strong> </p>
	<p class="small-section"> <strong>Developed By <a href="https://quetech.info/" target=_blank>Quetech IT Solution </a></strong</p>
	<ul class="footer-crumbs">
		<li class="terms"><a href="#" title="View the Free Lottery Terms and Conditions">Terms</a></li>
		<li class="privacy"><a href="<?= base_url('privacy-policy') ?>" title="View the Free Lottery Privacy Policy">Privacy</a></li>
		<li class="cookie-policy"><a href="#" title="View the Free Lottery Cookie Policy">Cookie Policy</a></li>
		<li class="disclaimer"><a href="#" title="View the Free Lottery Disclaimer">Disclaimer</a></li>
		<li class="disclaimer"><a href="#" title="View the Small Lottery Sitemap">Sitemap</a></li>
	</ul>
	
	
		
		<style type="text/css">
			#jackpotPromo {
				background: rgb(206,53,61);
				background: -moz-linear-gradient(top,  rgba(206,53,61,1) 0%, rgba(174,49,55,1) 100%);
				background: -webkit-linear-gradient(top,  rgba(206,53,61,1) 0%,rgba(174,49,55,1) 100%);
				background: linear-gradient(to bottom,  rgba(206,53,61,1) 0%,rgba(174,49,55,1) 100%);
				position: fixed; bottom: -180px; width: 100%; height: 90px; color: #FFF; left: 0;
			}
			#promotion-center {position: relative; width: 960px; height: 100px; margin: auto; text-align: center;}
			#promotion-logo {position: absolute; top: 20px; left: 10px; width: 200px; z-index: 99;}
			#promotion-date {position: absolute; width: 280px; left: 260px; top: 10px; font: normal 14px/30px open-sans, sans-serif; letter-spacing: 2px; z-index: 99;}
			#promotion-jackpot {position: absolute; width: 280px; left: 260px; top: 30px; font: bold 46px/50px open-sans, sans-serif; letter-spacing: -3px; z-index: 99;}
			#promotion-countdown {position: absolute; width: 200px; height: 48px; top: 20px; left: 570px; z-index: 99;}
			a#promotion-play {position: absolute; padding: 5px 30px; font: bold 18px/30px open sans, sans-serif; text-decoration: none; top: 25px; right: 0; border-radius: 12px; cursor: pointer; z-index: 99;}
			#promotion-close {background: rgb(206,53,61); position: absolute; top: -30px; height: 30px; width: 80px; border-radius: 8px 8px 0 0; text-align: center; color: #FFF; font: bold 14px/30px open sans, sans-serif; right: 10px; cursor: pointer; z-index: 99;}
			.counterPart {position: relative; border-radius: 6px; display: inline-block; *display: inline; zoom: 1; width: 40px; height: 50px; text-align: center; margin-right: 2px;}
			.counterType {position: absolute; font: 11px/16px open-sans, sans-serif; color: #FD0; bottom: 0; line-height: 16px; left: 0; width: 100%;}
			.counterVal {position: relative; font: 28px/30px open-sans, sans-serif; color: #FFF; display: block;}
		</style>
		
		<div id="jackpotPromo" style="position: fixed; bottom: -180px; width: 100%; height: 90px; color: #FFF; left: 0; z-index: 9999;">
			<div id="promotion-center">
				<img src="<?= base_url('assets');?>/images/promos/euromillions-logo.png" alt="EuroMillions" id="promotion-logo" />
				<div id="promotion-date">Friday 5th February 2021</div>
				<div id="promotion-jackpot">€130 Million!</div>
				<div id="promotion-countdown">
			<script type="text/javascript">
			<!-- 
				var days1 = 1;
				var hours1 = 9;
				var minutes1 = 17;
				var seconds1 = 47;
				var countdown1 = document.getElementById('promotion-countdown');
				
				function display1() {
					
					if (days1 > 0 || hours1 > 0 || minutes1 > 0 || seconds1 > 0) {
						
						if (hours1 <= 0 && minutes1 <= 0 && seconds1 <= 0) {hours1 = 23; minutes1 = 59; seconds1 = 59; days1 -= 1}
						else if (minutes1 <= 0 && seconds1 <= 0) {minutes1 = 59; seconds1 = 59; hours1 -= 1}
						else if (seconds1 <= 0) {seconds1 = 59; minutes1 -= 1}
						else {seconds1 -= 1}
						
						//if (String(hours1).length == 1) {hours1 = "0" + hours1;}
						//if (String(minutes1).length == 1) {minutes1 = "0" + minutes1;}
						//if (String(seconds1).length == 1) {seconds1 = "0" + seconds1;}
						
						countdown1.innerHTML = "<span class='counterPart'><span class='counterType'>days</span><span class='counterVal'>" + days1 + "</span></span>"
						countdown1.innerHTML += "<span class='counterPart'><span class='counterType'>hours</span><span class='counterVal'>" + hours1 + "</span></span>"
						countdown1.innerHTML += "<span class='counterPart'><span class='counterType'>mins</span><span class='counterVal'>" + minutes1 + "</span></span>"
						countdown1.innerHTML += "<span class='counterPart'><span class='counterType'>secs</span><span class='counterVal'>" + seconds1 + "</span></span>"
						setTimeout("display1()",1000);
						
					} else {
						countdown1.innerHTML = "<span class='counterPart'><span class='counterType'>days</span><span class='counterVal'>0</span></span>"
						countdown1.innerHTML += "<span class='counterPart'><span class='counterType'>hours</span><span class='counterVal'>0</span></span>"
						countdown1.innerHTML += "<span class='counterPart'><span class='counterType'>mins</span><span class='counterVal'>0</span></span>"
						countdown1.innerHTML += "<span class='counterPart'><span class='counterType'>secs</span><span class='counterVal'>0</span></span>"
					}
					
				};
				
				display1();
			--> 
			</script>
			<noscript>
				<span class="counterPart"><span class="counterType">days</span><span class="counterVal">1</span></span>
				<span class="counterPart"><span class="counterType">hours</span><span class="counterVal">9</span></span>
				<span class="counterPart"><span class="counterType">mins</span><span class="counterVal">17</span></span>
				<span class="counterPart"><span class="counterType">secs</span><span class="counterVal">47</span></span>
			</noscript></div>
				
					<a href="https://traffic.mylotto.com/?t=40446&amp;b=3&amp;p=5&amp;l=1&amp;lid=100&amp;bid=" rel="nofollow" target="_blank" class="btn-default" id="promotion-play">Play Now</a>
				
			</div>
			<div id="promotion-close" onclick="closePromo();">Close &times;</div>
		</div>
		
		<script type="text/javascript">
		<!--
			var slideTimer;
			
			function closePromo() {
				slide('down');
				setCookie();
			};
		
			function slide(direction) {
				var promo = document.getElementById("jackpotPromo");
				var bottom = parseInt(promo.style.bottom.replace('px',''));
				if (direction == 'up') {
					bottom += 2;
					promo.style.bottom = bottom + 'px';
					if (bottom == 0) {clearTimeout(slideTimer);}
					else {slideTimer = setTimeout("slide('up')",5);}
				} else if (direction == 'down') {
					bottom -= 2;
					promo.style.bottom = bottom + 'px';
					if (bottom == -180) {clearTimeout(slideTimer);}
					else {slideTimer = setTimeout("slide('down')",5);}
				}
			}
			
			window.onload = function() {
				if (!getCookie("JackpotPromo")) {setTimeout("slide('up')",1500);}
				else {promo.style.display = 'none';}
			};
		-->
		</script>
		
	


	<script type="text/javascript">
	<!--
		function getCookie(cookieName) {
			var i,x,y,allCookies = document.cookie.split(";");
			for (i = 0; i < allCookies.length; i++) {
				x = allCookies[i].substr(0,allCookies[i].indexOf("="));
				y = allCookies[i].substr(allCookies[i].indexOf("=")+1);
				x = x.replace(/^\s+|\s+$/g,"");
				if (x == cookieName) {return unescape(y)}
			}
		};
		
		function setCookie() {
			var cookieExpire = new Date();
			cookieExpire.setDate(cookieExpire.getDate() + 1);
			var cookieValue	= escape('JackpotPromo') + ( (1 == null) ? "" : "; expires="+cookieExpire.toUTCString()+"; path=/" );
			document.cookie = 'JackpotPromo' + "=" + cookieValue;
		};
	-->	
	</script>



	
</div>




<script type="text/javascript">

	
	
		(function() {
			
			var minheight = -124;
			var maxheight = 0;
			var time = 300;
			var timer = null;
			var toggled = false;
			
			window.onload = function() {
				
				if (document.getElementById('quickPick')) {
					SelectedBalls();	
				}
				
				var panelBtn = document.getElementById('panelButton');
				var panelBtnCls = document.getElementById('panel-close');
				
				if (panelBtn.addEventListener) {
					panelBtn.addEventListener("click", loginSlider);
					panelBtnCls.addEventListener("click", loginSlider);
				} else {
					panelBtn.attachEvent("onclick", loginSlider);
					panelBtnCls.attachEvent("onclick", loginSlider);
				}
				
				var slider = document.getElementById('login-panel');
				slider.style.marginTop = minheight + 'px';
				
				function loginSlider() {
					
					clearInterval(timer);
					var instanceheight = parseInt(slider.style.marginTop);
					var init = (new Date()).getTime();
					var height = (toggled = !toggled) ? maxheight : minheight;
					var disp = height - parseInt(slider.style.marginTop);
					
					timer = setInterval(function() {
						var instance = (new Date()).getTime() - init;
						if (instance < time) {
							var con = instance / time;
							var pos = Math.floor(disp * con);
							result = instanceheight + pos;
							slider.style.marginTop = result + 'px';
						} else {
							slider.style.marginTop = height + 'px';
							/*safety side ^^*/
							clearInterval(timer);
						}
					}, 1);
				};
			};
			
		})();
		
	
	
</script>



	<script type="text/javascript">
	
		function checkloginForm() {
			
			if (document.getElementById("Email0").value == "") {
				alert("Please enter your email address.");
				document.getElementById("Email0").focus();
				return false;
			} else {
				apos = document.getElementById("Email0").value.indexOf("@");
				dotpos = document.getElementById("Email0").value.lastIndexOf(".");

				if (apos < 1 || dotpos - apos < 2) {
					alert("Please enter a valid email address.");
					document.getElementById("Email0").focus();
					return false;
				}
			}
			
			if (document.getElementById("Password0").value == "") {
				alert("Please enter a password.");
				document.getElementById("Password0").focus();
				return false;
			}
			
			return true;
		}
		
	</script>
	

</body>


</html>