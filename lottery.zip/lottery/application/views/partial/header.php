<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>small Lottery | small Online Daily Lottery </title>
    <meta name="description" content="This global small Lottery can be entered worldwide, every day! Win big cash prizes with &pound;500 Daily Draws &amp; £10,000 Weekly Draws. Prizes guaranteed weekly." />
    <meta name="keywords" content="small lottery, small lotto, small, lottery, draw, win, million" />

    <!-- Open Graph Declarations: -->
    <meta property="og:title" content="small Lottery | small Online Daily Lottery - Prizes up to £10,000" />
    <meta property="og:description" content="This global small Lottery can be entered worldwide, every day! Win big cash prizes with &pound;500 Daily Draws &amp; £10,000 Weekly Draws. Prizes guaranteed weekly." />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="index.html" />
    <meta property="og:site_name" content="small Lottery" />
    <meta property="og:image" content="images/facebook-og.jpg" />

    <meta name="msvalidate.01" content="11471E99401076B1C7C0D03EFB0AF2F1" />

    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />

    <link href="<?= base_url('assets');?>/css/style327b.css?v=201906271349" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,800" rel="stylesheet" type="text/css">



    <script type="text/javascript">
        function addLoadEvent(e) {
            var t = window.onload;
            if (typeof window.onload != "function") {
                window.onload = e
            } else {
                window.onload = function() {
                    if (t) {
                        t()
                    }
                    e()
                }
            }
        }
    </script>
    <script type="text/javascript" src="<?= base_url('assets'); ?>/js/jquery.js"></script>

    <script type="text/javascript" src="<?= base_url('assets'); ?>/js/bind-polyfill.min.js"></script>
    <script type="text/javascript" src="<?= base_url('assets'); ?>/js/smooth-scroll.min.js"></script>
    <script type="text/javascript" src="<?= base_url('assets'); ?>/js/ticket-generator.js"></script>

    <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '../www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-11658017-6', 'auto');
        ga('require', 'linkid', 'linkid.html');
        ga('require', 'displayfeatures');
        ga('send', 'pageview');
    </script>


</head>

<body>
    

               