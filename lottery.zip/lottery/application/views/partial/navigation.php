<div class="navbar-wrapper">

	<div class="container">

		<div class="logo"><a href="<?= base_url();?>" title="smallllottery"><img src="<?php echo base_url('assets'); ?>/images/template/logo.png" alt="Small Lottery Logo"></a></div>

		<div class="navbar">
		
			
			
			<ul class="nav">

				
				
					<li class="active"><a href="<?= base_url();?>" title="smalllottery">Home</a></li>
					
					<li>
						<div class="dropdown">
							<div class="dropbtn"><a href="<?= base_url('howitworks') ?>" title="How it Works" class="dropbtn">How it Works</a></div>
							<div class="dropdown-content">
								<a href="<?= base_url('rules') ?>">Rules</a>
							</div>
						</div>
					</li>
					<li class=" results">
						<div class="dropdown">
							<div><a href="#priceplan" title="Latest Samll Lottery Plans"  class="dropbtn">Plans</a></div>
							
								
						</div>
					</li>
					<li>
						<div class="dropdown">
							<a href="help.html" title="Help and Support" class="dropbtn">Help &amp; Info</a>
							<div class="dropdown-content">
								<a href="<?= base_url('faq') ?>">FAQs</a>
								<a href="<?= base_url('contact') ?>">Contact us</a>
								<a href="<?= base_url('scams') ?>">Scams</a>
								<a href="<?= base_url('safesender') ?>">Safe Sender</a>
							</div>
						</div>
					</li>        
					           
					<li class=" winners">
						<div class="dropdown">
							<a href="winners.html" title="Previous Winners" class="dropbtn">Winners</a>
							<div class="dropdown-content">
								<a href="competitions.html">Competitions</a>
							</div>
						</div>
					</li>
					<li class="active"><a href="<?= base_url('register') ?>" title="More Online Lottery Games">Create Accont</a></li>
					<li class="active"><a href="<?= base_url('login') ?>" title="create account">Login</a></li>
				
			</ul>
		</div>
		
		

	</div>
	
	
	
		<div class="container">
			<div class="home-jackpot-box">
				<h1>Play Small Lottery every day and win up to <br><span style="text-transform: uppercase">&pound;10,000!</span></h1>
				<a href="#quickPick" title="Click here to enter for free right now!" data-scroll class="btn" style="font-size: 24px;" onClick="setTimeout('animatedRandomBalls()',800);">Start Playing &darr;</a>
			</div>
		</div>
		
	

</div>