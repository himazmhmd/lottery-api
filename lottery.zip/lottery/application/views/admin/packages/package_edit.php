  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
      <div class="card card-default">
        <div class="card-header">
          <div class="d-inline-block">
            <h3 class="card-title"> <i class="fa fa-pencil"></i>
              &nbsp; <?= trans('edit_user') ?> </h3>
          </div>
          <div class="d-inline-block float-right">
            <a href="<?= base_url('admin/packages'); ?>" class="btn btn-success"><i class="fa fa-list"></i> Packages List</a>
            <a href="<?= base_url('admin/packages/add'); ?>" class="btn btn-success"><i class="fa fa-plus"></i> Add New Package</a>
          </div>
        </div>
        <div class="card-body">

          <!-- For Messages -->
          <?php $this->load->view('admin/includes/_messages.php') ?>

          <?php echo form_open(base_url('admin/packages/edit/' . $user['id']), 'class="form-horizontal"') ?>
          <div class="form-group">
            <label for="username" class="col-md-2 control-label">Title</label>

            <div class="col-md-12">
              <input type="text" name="title" value="<?= $user['title']; ?>" class="form-control" id="username" placeholder="">
            </div>
          </div>
          <div class="form-group">
            <label for="firstname" class="col-md-2 control-label">price</label>

            <div class="col-md-12">
              <input type="text" name="price" value="<?= $user['price']; ?>" class="form-control" id="firstname" placeholder="">
            </div>
          </div>

          <div class="form-group">
            <label for="lastname" class="col-md-2 control-label">No Of Tickets</label>

            <div class="col-md-12">
              <input type="text" name="no_of_ticket" value="<?= $user['no_of_tickets']; ?>" class="form-control" id="lastname" placeholder="">
            </div>
          </div>

          <div class="form-group">
            <label for="email" class="col-md-2 control-label">Reward</label>

            <div class="col-md-12">
              <input type="text" name="details" value="<?= $user['details']; ?>" class="form-control" id="email" placeholder="">
            </div>
          </div>

          <div class="form-group">
            <label for="role" class="col-md-2 control-label"><?= trans('status') ?></label>

            <div class="col-md-12">
              <select name="status" class="form-control">
                <option value=""><?= trans('select_status') ?></option>
                <option value="1" <?= ($user['is_active'] == 1) ? 'selected' : '' ?>>Active</option>
                <option value="0" <?= ($user['is_active'] == 0) ? 'selected' : '' ?>>Deactive</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <div class="col-md-12">
              <input type="submit" name="submit" value="Update Package" class="btn btn-primary pull-right">
            </div>
          </div>
          <?php echo form_close(); ?>
        </div>
        <!-- /.box-body -->
      </div>
    </section>
  </div>