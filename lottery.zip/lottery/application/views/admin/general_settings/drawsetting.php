<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="card card-default color-palette-bo">
            <div class="card-header">
              <div class="d-inline-block">
                  <h3 class="card-title"> <i class="fa fa-plus"></i>
                  <?= trans('draw_settings') ?> </h3>
              </div>
            </div>
            <div class="card-body">   
                 <!-- For Messages -->
                <?php $this->load->view('admin/includes/_messages.php') ?>

                <?php echo form_open_multipart(base_url('admin/general_settings/draw_settings')); ?>	

                 <!-- Tab panes -->
                <div class="tab-content">
                    <!-- General Setting -->
                    <div role="tabpanel" class="tab-pane active" id="main">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label">Current Date and time</label>
                            <input type="text" Value="<?php echo html_escape($general_settings['draw']); ?>" class="form-control" name="draw" placeholder="Draw Time"
                            readonly>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label">Draw</label>
                            <input type="datetime-local" class="form-control" name="draw" placeholder="Draw Time"
                            value="">
                        </div>
                    </div>
                    </div>
                     <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label">Day</label>
                            <input type="text" class="form-control" Value="<?php echo html_escape($general_settings['day']); ?>" name="day" placeholder="Day"
                            value="">
                        </div>
                    </div>
                    </div>
                </div>
                <div class="col-md-4">
                <div class="box-footer">
                    <input type="submit" name="submit" value="<?= trans('save_changes') ?>" class="btn btn-primary pull-right">
                </div>	
                </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </section>
</div>

<script>
    $("#setting").addClass('active');
    $('#myTabs a').click(function (e) {
     e.preventDefault()
     $(this).tab('show')
 })
</script>
