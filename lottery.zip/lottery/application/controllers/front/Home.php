<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	
	public function index()
	{
        
		 $this->load->view('partial/header');
		$this->load->view('partial/navigation');
		$this->load->view('home/steps');
		$this->load->view('home/index');
		$this->load->view('partial/footer');
        
	} 
}
