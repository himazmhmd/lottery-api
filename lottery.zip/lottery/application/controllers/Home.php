<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->library('mailer');
		$this->load->model('admin/auth_model', 'auth_model');
		$this->load->model('admin/crud_model');
		$this->load->model('admin/user_model');
		// Load paypal library 
		$this->load->library('paypal_lib');
		$this->load->model('payment_model');
	}
	public function index()
	{
		$this->db->where('is_active', 1);
		$data['plans'] =	$this->db->get('packages')->result_array();
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front//steps');
		$this->load->view('front/plans', $data);
		$this->load->view('front/index');
		$this->load->view('partial/footer');
	}
	public function login()
	{
		if ($this->session->has_userdata('user_id')) {
			redirect('home/dashboard');
		}

		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front//login');
		$this->load->view('front/index');
		$this->load->view('partial/footer');
		if ($this->input->post('btn2')) {
			$data = array(
				'email' => $this->input->post('email'),
				'password' => $this->input->post('password')
			);
			$result = $this->auth_model->check_login($data);

			if ($result) {
				if ($result['is_active'] == 0) {
					$this->session->set_flashdata('error', 'Account is disabled by Admin!');
					redirect(base_url('home/login'));
					exit();
				}
			} else {
				$this->session->set_flashdata('error', 'Invalid Username or Password!');
				redirect(base_url('home/login'));
			}

			if ($result['is_admin'] == 3) {
				$user_data = array(
					'user_id' => $result['id'],
					'username' => $result['username'],
					'email' => $result['email'],
					'role_id' => $result['is_admin'],
					'package' => $result['package'],
					'login' => True

				);

				$this->session->set_userdata($user_data);

				redirect(base_url('home/dashboard'), 'refresh');
			}
		}
	}




	public function dashboard()
	{
		if (!$this->session->has_userdata('user_id')) {
			redirect('home/login');
		}
		$data['package'] = $this->crud_model->user_package($this->session->userdata('user_id'));
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/dashboard', $data);
		$this->load->view('front/index');
		$this->load->view('partial/footer');
	}



	public function acc_setting()
	{
		if (!$this->session->has_userdata('user_id')) {
			redirect('home/login');
		}
		$data['user'] = $this->user_model->get_user_by_id($this->session->userdata('user_id'));
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/account_setting', $data);
		$this->load->view('partial/footer');
	}
	public function playgame()
	{
		if ($this->session->userdata('login') !== true) {
			$this->session->set_flashdata('error', 'Please login First');
			redirect('home/login');
		}
		$userid = $this->session->userdata('user_id');
		$this->db->where('id', $userid);
		$query = $this->db->get('ci_users');
		$result = $query->row_array();
		if ($result['package'] == 0) {
			$this->session->set_flashdata('error', 'Kindly Select any ticket plan to continue  ');
			redirect('home/plans');
		} else {
			//$data = $this->crud_model->get_packages($result['package']);
            $data['package']=$result['package'];
			$this->load->view('partial/header');
			$this->load->view('partial/nav2');
			$this->load->view('front/view_ticket',$data);
			$this->load->view('partial/footer');
		}
	}

	public function ticket_generate()
	{
		if (isset($_POST['btn3'])) {
			$weeklyNumber =  $this->input->post('weeklynumbers');
			$numbers = explode("|", $weeklyNumber);
			$num1 = $numbers['0'];
			$num2 = $numbers['1'];
			$num3 = $numbers['2'];
			$num4 = $numbers['3'];
			$num5 = $numbers['4'];
			$num6 = $numbers['5'];
			$data = array(
				'package_id' =>	$this->input->post('package_id'),
				'user_id' =>	$this->input->post('user_id'),
				'BO_1' => $num1,
				'BO_2' => $num2,
				'BO_3' => $num3,
				'BO_4' => $num4,
				'BO_5' => $num5,
				'BO_6' => $num6
			);
			$inserted = $this->db->insert('users_ticket', $data);
			$data['email'] = $this->db->get_where('ci_users', array('id' => $this->input->post('user_id')))->row()->email;
			$sended	= $this->send_mail($data);
			if ($inserted && $sended) {
			    $data=array(
					'package' =>0,
				);
				$user_id = $this->session->userdata('user_id');
		        $this->user_model->edit_user($data, $user_id);
				$this->session->set_flashdata('success', 'Ticket Generated Successfully,please check your email');

				redirect('home/dashboard');
			} else {
				$this->session->set_flashdata('error', 'Somthing Went wrong!');
				redirect('home/dashboard');
			}
		}
	}


	public function payment_gateway($package_id)
	{
		$data['id'] = $package_id;
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/payment_gateway', $data);
		$this->load->view('partial/footer');
	}

	public function buy($package_id)
	{
		if ($this->session->userdata('login') !== true) {
			redirect('home/login');
		}
		$returnURL = base_url() . 'home/paymentSuccess'; //payment success url 
		$cancelURL = base_url() . 'home/cancel'; //payment cancel url 
		$notifyURL = base_url() . 'home/ipn'; //ipn url 
		$logo = base_url() . 'assets/images/template/logo.png';
		$this->db->where('id', $package_id);
		$query = $this->db->get('packages');
		$result = $query->row_array();

		$user_id = $this->session->userdata('user_id');
		$this->paypal_lib->add_field('return', $returnURL);
		$this->paypal_lib->add_field('cancel_return', $cancelURL);
		$this->paypal_lib->add_field('notify_url', $notifyURL);
		$this->paypal_lib->add_field('item_name', $result['title']);
		$this->paypal_lib->add_field('custom', $user_id);
		$this->paypal_lib->add_field('item_number',  $result['id']);
		$this->paypal_lib->add_field('amount',  $result['price']);
		$this->paypal_lib->image($logo);
		$this->paypal_lib->paypal_auto_form();
	}
	function paymentSuccess()
	{
		$paypalInfo = $this->input->get();
		$productData = $paymentData = array();
		if (!empty($paypalInfo['item_number']) && !empty($paypalInfo['tx']) && !empty($paypalInfo['amt']) && !empty($paypalInfo['cc']) && !empty($paypalInfo['st'])) {
			$item_name = $paypalInfo['item_name'];
			$item_number = $paypalInfo['item_number'];
			$txn_id = $paypalInfo["tx"];
			$payment_amt = $paypalInfo["amt"];
			$currency_code = $paypalInfo["cc"];
			$status = $paypalInfo["st"];

			// Get product info from the database 
			$this->db->where('id',   $item_number);
			$package_id = $this->db->get('packages')->row()->id;
			$this->db->where('id',   $txn_id);
			$query = $this->db->get('payments');
			$paymentData = $query->row_array();
		}
		$data = array('package' => 	$package_id);
		$user_id = $this->session->userdata('user_id');
		$updated = $this->user_model->edit_user($data, $user_id);

		if ($updated) {
			$this->session->set_flashdata('success', 'Payment Done Successfully,now you can generate ticket');
			redirect('home/dashboard');
		}else{
			$this->session->set_flashdata('success', 'Something Went Wrong try again');
			redirect('home/dashboard');

		}
	
	}
	function ipn()
	{
		// Retrieve transaction data from PayPal IPN POST 
		$paypalInfo = $this->input->post();

		if (!empty($paypalInfo)) {
			// Validate and get the ipn response 
			$ipnCheck = $this->paypal_lib->validate_ipn($paypalInfo);

			// Check whether the transaction is valid 
			if ($ipnCheck) {
				// Check whether the transaction data is exists 
				$prevPayment = $this->payment_model->getPayment(array('txn_id' => $paypalInfo["txn_id"]));
				if (!$prevPayment) {
					// Insert the transaction data in the database 
					$data['user_id']    = $paypalInfo["custom"];
					$data['package_id']    = $paypalInfo["item_number"];
					$data['txn_id']    = $paypalInfo["txn_id"];
					$data['payment_gross']    = $paypalInfo["mc_gross"];
					$data['currency_code']    = $paypalInfo["mc_currency"];
					$data['payer_name']    = trim($paypalInfo["first_name"] . ' ' . $paypalInfo["last_name"], ' ');
					$data['payer_email']    = $paypalInfo["payer_email"];
					$data['status'] = $paypalInfo["payment_status"];

					$this->payment_model->insertTransaction($data);
				}
			}
		}
	}
	public function plans()
	{
		$this->db->where('is_active', 1);
		$data['plans'] =	$this->db->get('packages')->result_array();
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/plans', $data);
		$this->load->view('front/index');
		$this->load->view('partial/footer');
	}
	public function winners()
	{

	$sql = "SELECT TIME_FORMAT(draw,'%h:%i %p') FROM ci_general_settings";
	    $data['time'] = $this->db->query($sql)->row();
        $data['dat']= $this->db->get('ci_general_settings')->row()->draw;
	    $data['day']= $this->db->get('ci_general_settings')->row()->day;
	    $data['winners'] = $this->db->get('winners')->result_array();
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/winners',$data);
		$this->load->view('partial/footer');
	}
	public function privacy()
	{
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/privacy');
		$this->load->view('partial/footer');
	}
	public function term_condition()
	{
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/term');
		$this->load->view('partial/footer');
	}
	public function contact()
	{
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/contact');
		$this->load->view('partial/footer');
	}
	public function help()
	{
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/help');
		$this->load->view('partial/footer');
	}
	public function change_password()
	{

		if (!$this->session->has_userdata('user_id')) {
			redirect('home/login');
		}
		$user = $this->user_model->get_user_by_id($this->session->userdata('user_id'));
		if (isset($_POST['btn1'])) {
			$cur = $this->input->post('CurrentPassword');
			if ($cur != $user['password']) {
				$this->session->set_flashdata('error', 'You Current password is wrong!');
				redirect('change_password');
			} else {

				$data = array(
					'password' => $this->input->post('Password'),
				);
			}
			$updated = $this->user_model->edit_user($data, $this->session->userdata('user_id'));
			if ($updated) {
				$this->session->set_flashdata('success', 'Your Password updated successfully');

				redirect('change_password');
			}
		}
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/change_password');
		$this->load->view('partial/footer');
	}
	public function edit_settings()
	{
		if (!$this->session->has_userdata('user_id')) {
			redirect('home/login');
		}
		$data['user'] = $this->user_model->get_user_by_id($this->session->userdata('user_id'));
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/edit_setting', $data);
		$this->load->view('partial/footer');
	}
	public function update_setting($id)
	{

		if (isset($_POST['btn1'])) {
			$data = array(
				'firstname' =>	$this->input->post('firstname'),
				'lastname' =>	$this->input->post('surname'),
				'username' => $this->input->post('username'),
				'email' =>	$this->input->post('email'),
				'card_number' =>	$this->input->post('card_number'),
				'exp_month' =>	$this->input->post('exp_month'),

				'country' =>	$this->input->post('country'),
				'mobile_no' =>	$this->input->post('mobile_number')

			);
			$updated = $this->user_model->edit_user($data, $id);
			if ($updated) {
				$this->session->set_flashdata('success', 'Personal Information updated successfully');

				redirect('home/edit_settings');
			} else {
				$this->session->set_flashdata('error', 'Somthing Went wrong!');
				redirect('home/edit_settings');
			}
		}


		$data['user'] = $this->user_model->get_user_by_id($this->session->userdata('user_id'));
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/edit_setting', $data);
		$this->load->view('partial/footer');
	}
	public function register()
	{
		if ($this->session->has_userdata('user_id')) {
			redirect('home/acc_setting');
		}
		$this->load->view('partial/header');
		$this->load->view('partial/nav2');
		$this->load->view('front/register');
		$this->load->view('partial/footer');
		if (isset($_POST['playn'])) {

			$email = $this->input->post('Email');
			$this->db->where('email', $email);
			$query = $this->db->get('ci_users');
			if ($query->num_rows() > 0) {
				$this->session->set_flashdata('error', 'You are already registerd!');
				redirect('login');
			}
			$data = array(
				'firstname' =>	$this->input->post('FirstName'),
				'lastname' =>	$this->input->post('Surname'),
				'username' => $this->input->post('FirstName') . $this->input->post('Surname'),
				'email' =>	$this->input->post('Email'),
				'password' =>  $this->input->post('Password'),
				'term' =>	$this->input->post('AcceptTerms'),
				'card_number' =>	$this->input->post('card_number'),
				'exp_month' =>	$this->input->post('exp_month'),

			);



			$data = $this->security->xss_clean($data);

			$inserted = $this->db->insert('ci_users', $data);
			if ($inserted) {
				$this->session->set_flashdata('success', 'You are successfully Registered');
				redirect('login');
			} else {
				$this->session->set_flashdata('error', 'Somthing Went wrong!');
				redirect('register');
			}
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('home/login'), 'refresh');
	}

	public function test()
	{

		$num1 = 11;
		$num2 = 21;
		$num3 = 39;
		$num4 = 40;
		$num5 = 57;
		$num6 = 66;
		$data = array(

			'BO_1' => $num1,
			'BO_2' => $num2,
			'BO_3' => $num3,
			'BO_4' => $num4,
			'BO_5' => $num5,
			'BO_6' => $num6
		);

		$this->data['data'] = $data;


		$this->data['data'] = $data;
		$this->load->view('front/ticket_template');
	}
	public function send_mail($data)
	{
		$this->data['data'] = $data;

		$config = array(
			'protocol' => 'smtp',
			'smtp_host' => 'smalllottery.com',
			'smtp_port' => 465,
			'smtp_user' => 'info@smalllottery.com',
			'smtp_pass' => '%d2HNyJ#(EY!',
			'smtp_timeout' => '4',
			'mailtype'  => 'html',
			'charset'   => 'utf-8',
			'wordwrap' => TRUE
		);
		$this->load->library('email', $config);
		foreach ($this->data as $row) {
			$mail =	$row['email'];
		}
		$fromemail = "info@smalllottery.com";
		$toemail = $mail;
		$subject = "Email From Small lottery";
	
		$mesg = $this->load->view('front/ticket_template', $this->data, true);

		$config = array(
			'charset' => 'utf-8',
			'wordwrap' => TRUE,
			'mailtype' => 'html'
		);

		$this->email->initialize($config);

		$this->email->to($toemail);
		$this->email->from($fromemail, "Title");
		$this->email->subject($subject);
		$this->email->message($mesg);
		return	$mail = $this->email->send();
	}
}
