<?php defined('BASEPATH') OR exit('No direct script access allowed');



class Userdashboard extends My_Controller {

	public function __construct(){
		parent::__construct();
		  // Load paypal library 
		  $this->load->library('paypal_lib'); 
	}
	public function index(){
		if (!$this->session->has_userdata('user_id')) {
			redirect('home/login');
		}
		$data['title'] = 'Dashboard';
		$data['title'] = 'Dashboard';

		$this->load->view('admin/includes/userheader', $data);

    	$this->load->view('admin/dashboard/userindex', $data);

    	$this->load->view('admin/includes/_footer');
	}
	 public function package(){
		if($this->session->userdata('login')!==true){
            redirect('home/login');
        }
		$data['plans'] =	$this->db->get('packages')->result_array();
		$data['title'] = 'Dashboard';
		$this->load->view('admin/includes/userheader', $data);

    	$this->load->view('admin/dashboard/plans', $data);

    	//$this->load->view('admin/includes/_footer');

	 }
	 public function play(){
		if($this->session->userdata('login')!==true){
            redirect('home/login');
        }
		
		$data['plans'] =	$this->db->get('packages')->result_array();
		$data['title'] = 'Dashboard';
		$this->load->view('admin/includes/userheader', $data);

    	$this->load->view('admin/dashboard/play', $data);

    	//$this->load->view('admin/includes/_footer');

	 }

	 public function buy($package_id){
		if($this->session->userdata('login')!==true){
            redirect('home/login');
        }
		$returnURL = base_url().'paypal/success'; //payment success url 
        $cancelURL = base_url().'paypal/cancel'; //payment cancel url 
        $notifyURL = base_url().'paypal/ipn'; //ipn url 
		$this->db->where('id', $package_id); 
            $query = $this->db->get('packages'); 
            $result = $query->row_array();

		$user_id=$this->session->userdata('user_id');
	
		$this->paypal_lib->add_field('return', $returnURL); 
        $this->paypal_lib->add_field('cancel_return', $cancelURL); 
        $this->paypal_lib->add_field('notify_url', $notifyURL); 
        $this->paypal_lib->add_field('item_name', $result['title']); 
        $this->paypal_lib->add_field('custom', $user_id); 
        $this->paypal_lib->add_field('item_number',  $result['id']); 
        $this->paypal_lib->add_field('amount',  $result['price']); 
         
		$this->paypal_lib->paypal_auto_form(); 

	 }

}
