<?php defined('BASEPATH') or exit('No direct script access allowed');
class Winners extends MY_Controller
{

    public function __construct()
    {

        parent::__construct();
        auth_check(); // check login auth
        $this->rbac->check_module_access();

        $this->load->model('admin/user_model', 'user_model');
        $this->load->model('admin/Activity_model', 'activity_model');
    }

    //-----------------------------------------------------------
    public function index()
    {
       
        $this->load->view('admin/includes/_header');
        $this->load->view('admin/winners/winner_list');
        $this->load->view('admin/includes/_footer');
    }

    public function datatable_json()
    {
        $records['data'] = $this->db->get('winners')->result_array();
        $data = array();

        $i = 0;
        foreach ($records['data']   as $row) {
           
            $data[] = array(
                ++$i,
                '
                <img src=' . base_url("uploads/" . $row['image']) . ' height="50px;" alt="pic" />'
                ,
                $row['name'],
               
               
             '<a title="Delete" class="delete btn btn-sm btn-danger" href=' . base_url("admin/winners/delete/" . $row['id']) . ' title="Delete" onclick="return confirm(\'Do you want to delete ?\')"> <i class="fa fa-trash-o"></i></a>'
            );
        }
        $records['data'] = $data;
        echo json_encode($records);
        
    }

    //-----------------------------------------------------------
   



    public function add()
    {

        $this->rbac->check_operation_access(); // check opration permission

        if ($this->input->post('submit')) {
            $this->form_validation->set_rules('username', 'Username', 'trim|required');
            if ($this->form_validation->run() == FALSE) {
                $data = array(
                    'errors' => validation_errors()
                );
                $this->session->set_flashdata('errors', $data['errors']);
                redirect(base_url('admin/winners/add'), 'refresh');
            } else {
                $this->load->library('upload');
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']     = '100';
                $config['max_width'] = '1024';
                $config['max_height'] = '768';
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('file')) {
                    $this->session->set_flashdata('errors', $this->upload->display_errors());
                    redirect('admin/winners/add');
                } else {
                    $upload_data = $this->upload->data();
                    $file_name = $upload_data['file_name'];
                    $data = array(
                        'name' => $this->input->post('username'),
                        'image' =>  $file_name,
                        'message' => $this->input->post('message'),
                    );
                    $result = $this->db->insert('winners', $data);
                    if ($result) {
                     //   $this->session->set_flashdata('success', 'Winner has been added successfully!');
                        redirect(base_url('admin/winners'));
                    }
                }
            }
        } else {
            $this->load->view('admin/includes/_header');
            $this->load->view('admin/winners/winner_add');
            $this->load->view('admin/includes/_footer');
        }
    }

   

    public function delete($id = 0)
    {
        $this->rbac->check_operation_access(); // check opration permission
        $this->db->delete('winners', array('id' => $id));
      //  $this->session->set_flashdata('success', 'Winner has been deleted successfully!');
        redirect(base_url('admin/winners'));
    }
}
