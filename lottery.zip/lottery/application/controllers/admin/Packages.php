<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Packages extends MY_Controller {

	public function __construct(){

		parent::__construct();
		auth_check(); // check login auth
		$this->rbac->check_module_access();

		$this->load->model('admin/package_model', 'package_model');
		$this->load->model('admin/Activity_model', 'activity_model');
	}

	
	public function index(){

		$this->load->view('admin/includes/_header');
		$this->load->view('admin/packages/packages_list');
		$this->load->view('admin/includes/_footer');
	}
	
	public function datatable_json(){	
				   					   
		$records['data'] = $this->package_model->get_all_users();
		$data = array();

		$i=0;
		foreach ($records['data']   as $row) 
		{  
			$status = ($row['is_active'] == 1)? 'checked': '';
			//$verify = ($row['is_verify'] == 1)? 'Verified': 'Pending';
			$data[]= array(
				++$i,
				$row['title'],
				$row['price'],
				$row['no_of_tickets'],
				$row['details'],
				date_time($row['created_at']),	
				
				'<input class="tgl_checkbox tgl-ios" 
				data-id="'.$row['id'].'" 
				id="cb_'.$row['id'].'"
				type="checkbox"  
				'.$status.'><label for="cb_'.$row['id'].'"></label>',		

				'<a title="Edit" class="update btn btn-sm btn-warning" href="'.base_url('admin/packages/edit/'.$row['id']).'"> <i class="fa fa-pencil-square-o"></i></a>
				<a title="Delete" class="delete btn btn-sm btn-danger" href='.base_url("admin/packages/delete/".$row['id']).' title="Delete" onclick="return confirm(\'Do you want to delete ?\')"> <i class="fa fa-trash-o"></i></a>'
			);
		}
		$records['data']=$data;
		echo json_encode($records);						   
	}

	//-----------------------------------------------------------
	function change_status()
	{   
		$this->package_model->change_status();
	}

	public function add(){
		
		$this->rbac->check_operation_access(); // check opration permission

		if($this->input->post('submit')){
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('price', 'Price', 'trim|required');
			$this->form_validation->set_rules('no_of_ticket', 'Number of Tickets', 'trim|required');
			if ($this->form_validation->run() == FALSE) {
				$data = array(
					'errors' => validation_errors()
				);
				$this->session->set_flashdata('errors', $data['errors']);
				redirect(base_url('admin/packages/add'),'refresh');
			}
			else{
				$data = array(
					'title' => $this->input->post('title'),
					'price' => $this->input->post('price'),
					'no_of_tickets' => $this->input->post('no_of_ticket'),
					'details' => $this->input->post('details'),
					'created_at' => date('Y-m-d : h:m:s')
				);
				$data = $this->security->xss_clean($data);
				$result = $this->package_model->add_package($data);
				if($result){
					$this->session->set_flashdata('success', 'Package has been added successfully!');
					redirect(base_url('admin/packages'));
				}
			}
		}
		else{
			$this->load->view('admin/includes/_header');
			$this->load->view('admin/packages/package_add');
			$this->load->view('admin/includes/_footer');
		}
		
	}

	public function edit($id = 0){

		$this->rbac->check_operation_access(); // check opration permission

		if($this->input->post('submit')){
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('price', 'Price', 'trim|required');
			$this->form_validation->set_rules('no_of_ticket', 'Number of Tickets', 'trim|required');
			$this->form_validation->set_rules('status', 'Status', 'trim|required');
			if ($this->form_validation->run() == FALSE) {
					$data = array(
						'errors' => validation_errors()
					);
					$this->session->set_flashdata('errors', $data['errors']);
					redirect(base_url('admin/packages/package_edit/'.$id),'refresh');
			}
			else{
				$data = array(
					'title' => $this->input->post('title'),
					'price' => $this->input->post('price'),
					'no_of_tickets' => $this->input->post('no_of_ticket'),
					'details' => $this->input->post('details'),
					'is_active' => $this->input->post('status'),
					
				);
				$data = $this->security->xss_clean($data);
				$result = $this->package_model->edit_user($data, $id);
				if($result){
				
					$this->session->set_flashdata('success', 'Package has been updated successfully!');
					redirect(base_url('admin/packages'));
				}
			}
		}
		else{
			$data['user'] = $this->package_model->get_user_by_id($id);
			
			$this->load->view('admin/includes/_header');
			$this->load->view('admin/packages/package_edit', $data);
			$this->load->view('admin/includes/_footer');
		}
	}

	public function delete($id = 0)
	{
		$this->rbac->check_operation_access(); // check opration permission
		
		$this->db->delete('packages', array('id' => $id));

		

		$this->session->set_flashdata('success', 'package has been deleted successfully!');
		redirect(base_url('admin/packages'));
	}

}


?>