<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-05 20:20:34 --> Severity: error --> Exception: syntax error, unexpected '>' /home/quetjoxq/lottery.quetech.info/application/controllers/Paypal.php 86
ERROR - 2021-03-05 20:20:57 --> Severity: error --> Exception: syntax error, unexpected '>' /home/quetjoxq/lottery.quetech.info/application/controllers/Paypal.php 86
ERROR - 2021-03-05 20:25:47 --> Severity: error --> Exception: syntax error, unexpected '>' /home/quetjoxq/lottery.quetech.info/application/controllers/Paypal.php 86
ERROR - 2021-03-05 20:26:37 --> Severity: error --> Exception: syntax error, unexpected '>' /home/quetjoxq/lottery.quetech.info/application/controllers/Paypal.php 86
ERROR - 2021-03-05 20:27:25 --> Severity: error --> Exception: syntax error, unexpected '>' /home/quetjoxq/lottery.quetech.info/application/controllers/Paypal.php 86
ERROR - 2021-03-05 20:29:04 --> Severity: error --> Exception: syntax error, unexpected '>' /home/quetjoxq/lottery.quetech.info/application/controllers/Paypal.php 86
ERROR - 2021-03-05 20:31:40 --> Severity: error --> Exception: syntax error, unexpected '>' /home/quetjoxq/lottery.quetech.info/application/controllers/Paypal.php 86
