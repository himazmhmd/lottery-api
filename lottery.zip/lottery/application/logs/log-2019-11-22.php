<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-22 07:27:33 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-22 10:48:39 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-22 00:15:27 --> Query error: Table 'ci_roles_permissions.admin_roles' doesn't exist - Invalid query: SELECT *
FROM `admin_roles`
ERROR - 2019-11-22 11:18:15 --> 404 Page Not Found: admin/Admin/profile
ERROR - 2019-11-22 11:31:55 --> 404 Page Not Found: admin/Example/simple_database
ERROR - 2019-11-22 11:31:59 --> 404 Page Not Found: admin/Examples/simple_database
ERROR - 2019-11-22 11:32:05 --> 404 Page Not Found: admin/Example/simple_database
ERROR - 2019-11-22 11:59:52 --> 404 Page Not Found: admin/Invoices/invoices
ERROR - 2019-11-22 12:00:09 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-22 12:00:09 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-22 01:43:59 --> Query error: Table 'ci_roles_permissions.admin_roles' doesn't exist - Invalid query: SELECT *
FROM `admin_roles`
ERROR - 2019-11-22 17:54:37 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-22 19:08:44 --> 404 Page Not Found: admin/Module/index
ERROR - 2019-11-22 19:08:50 --> 404 Page Not Found: admin/Module/index
ERROR - 2019-11-22 19:08:54 --> 404 Page Not Found: Module/index
ERROR - 2019-11-22 19:09:08 --> 404 Page Not Found: admin/Add/index
ERROR - 2019-11-22 19:10:32 --> 404 Page Not Found: admin/Module/index
ERROR - 2019-11-22 19:10:35 --> 404 Page Not Found: admin/Module/index
ERROR - 2019-11-22 19:11:09 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-22 19:11:36 --> 404 Page Not Found: admin/Module/index
ERROR - 2019-11-22 19:11:40 --> 404 Page Not Found: admin/Module/index
ERROR - 2019-11-22 08:12:32 --> Query error: Table 'ci_roles_permissions.admin_roles' doesn't exist - Invalid query: SELECT *
FROM `admin_roles`
ERROR - 2019-11-22 19:13:26 --> 404 Page Not Found: admin/Admin/profile
ERROR - 2019-11-22 19:15:16 --> 404 Page Not Found: Dist/img
ERROR - 2019-11-22 19:30:04 --> 404 Page Not Found: admin/Tabels/simple
ERROR - 2019-11-22 19:30:05 --> 404 Page Not Found: admin/Tabels/data
ERROR - 2019-11-22 19:38:12 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2019-11-22 19:39:02 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2019-11-22 19:40:30 --> 404 Page Not Found: admin/Docs/index
ERROR - 2019-11-22 19:41:42 --> 404 Page Not Found: admin/Https:/adminlte.io
ERROR - 2019-11-22 20:21:59 --> 404 Page Not Found: admin/Extras/error500
ERROR - 2019-11-22 20:46:59 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-22 20:46:59 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-22 20:46:59 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-22 20:46:59 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-22 09:54:18 --> Severity: Notice --> Undefined property: General_settings::$parser F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\General_settings.php 134
ERROR - 2019-11-22 09:54:18 --> Severity: error --> Exception: Call to a member function parse() on null F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\General_settings.php 134
ERROR - 2019-11-22 20:54:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-11-22 20:54:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-11-22 20:54:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-11-22 20:54:54 --> 404 Page Not Found: Assets/admin
