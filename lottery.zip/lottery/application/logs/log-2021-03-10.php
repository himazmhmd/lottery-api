<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-10 12:29:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-10 12:29:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-10 12:30:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-10 12:30:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
