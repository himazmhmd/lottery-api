<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-19 10:42:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 10:42:53 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-19 12:01:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 16:17:13 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 33
ERROR - 2021-02-19 16:17:13 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 34
ERROR - 2021-02-19 16:17:13 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 35
ERROR - 2021-02-19 16:17:13 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 33
ERROR - 2021-02-19 16:17:13 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 34
ERROR - 2021-02-19 16:17:13 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 35
ERROR - 2021-02-19 16:18:01 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 33
ERROR - 2021-02-19 16:18:01 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 34
ERROR - 2021-02-19 16:18:01 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 35
ERROR - 2021-02-19 16:18:01 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 33
ERROR - 2021-02-19 16:18:01 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 34
ERROR - 2021-02-19 16:18:02 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 35
ERROR - 2021-02-19 16:19:21 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 33
ERROR - 2021-02-19 16:19:21 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 34
ERROR - 2021-02-19 16:19:21 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 35
ERROR - 2021-02-19 16:19:21 --> Severity: Notice --> Undefined index: details C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 36
ERROR - 2021-02-19 16:19:21 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 33
ERROR - 2021-02-19 16:19:21 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 34
ERROR - 2021-02-19 16:19:21 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 35
ERROR - 2021-02-19 16:19:21 --> Severity: Notice --> Undefined index: details C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 36
ERROR - 2021-02-19 16:21:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Package_model C:\xampp\htdocs\lottery\system\core\Loader.php 348
ERROR - 2021-02-19 16:23:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Package_model C:\xampp\htdocs\lottery\system\core\Loader.php 348
ERROR - 2021-02-19 16:34:18 --> Severity: Notice --> Undefined property: Packages::$user_model C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 86
ERROR - 2021-02-19 16:34:18 --> Severity: error --> Exception: Call to a member function add_user() on null C:\xampp\htdocs\lottery\application\controllers\admin\packages.php 86
ERROR - 2021-02-19 16:36:18 --> Query error: Unknown column 'no_of_ticket' in 'field list' - Invalid query: INSERT INTO `packages` (`title`, `price`, `no_of_ticket`, `details`, `created_at`) VALUES ('Awaken Your True Calling', '1200', '10', '', '2021-02-19 : 04:02:18')
ERROR - 2021-02-19 16:51:49 --> Query error: Unknown column 'updated_at' in 'field list' - Invalid query: UPDATE `packages` SET `title` = 'Basic', `price` = '100', `no_of_tickets` = '10', `details` = '', `is_active` = '0', `updated_at` = '2021-02-19 : 04:02:49'
WHERE `id` = '1'
ERROR - 2021-02-19 13:12:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 13:28:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 17:32:07 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-19 17:32:07 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-19 17:32:07 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-19 17:32:08 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-19 17:32:08 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-19 17:32:08 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-19 13:34:24 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-19 13:36:14 --> 404 Page Not Found: admin//index
ERROR - 2021-02-19 13:36:24 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-19 13:37:17 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-19 13:37:28 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-19 13:43:14 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-19 13:43:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 13:53:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 13:54:09 --> 404 Page Not Found: Results/index
ERROR - 2021-02-19 13:54:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 13:54:31 --> 404 Page Not Found: Home/plans
ERROR - 2021-02-19 13:54:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 13:54:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 13:54:46 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-19 00:15:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 18:48:00 --> 404 Page Not Found: Registerhtml/index
ERROR - 2021-02-19 19:56:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-19 19:56:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 19:56:39 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-19 19:58:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:00:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:09:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:15:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:16:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:17:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:18:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:21:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:22:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:24:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:24:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:27:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:32:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:32:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:34:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-19 20:34:14 --> 404 Page Not Found: Winnershtml/index
ERROR - 2021-02-19 20:36:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
