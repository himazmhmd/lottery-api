<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-19 03:19:36 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-19 15:26:46 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
