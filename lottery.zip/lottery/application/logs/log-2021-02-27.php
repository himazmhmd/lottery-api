<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-27 00:02:27 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 00:02:27 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 00:02:27 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 00:02:40 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 00:02:40 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 00:02:40 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 00:03:14 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 00:03:15 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 00:03:15 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 00:42:45 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 00:42:45 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 00:42:45 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:41:04 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:41:04 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:41:04 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 07:43:16 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 11:43:38 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:43:38 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:43:38 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:43:54 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:43:54 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:43:54 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:45:01 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:45:01 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:45:01 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 07:45:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 11:45:37 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:45:37 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:45:37 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 07:45:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 07:45:41 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 07:45:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 11:45:57 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:45:57 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:45:57 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:48:28 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:48:28 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:48:28 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:48:32 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:48:32 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:48:32 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:48:33 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:48:33 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:48:33 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:48:34 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:48:34 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:48:34 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:48:36 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:48:36 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:48:36 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:48:37 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:48:37 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:48:37 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:48:38 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:48:38 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:48:38 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:49:33 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:49:33 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:49:33 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:49:41 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:49:41 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:49:41 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:50:02 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:50:02 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:50:02 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 07:50:05 --> 404 Page Not Found: Userdashboard/packages
ERROR - 2021-02-27 07:50:53 --> 404 Page Not Found: Userdashboard/packages
ERROR - 2021-02-27 11:50:55 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:50:55 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:50:55 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:50:57 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:50:57 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:50:57 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 07:51:00 --> 404 Page Not Found: Userdashboard/package
ERROR - 2021-02-27 11:51:20 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:51:20 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:51:20 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:51:22 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 11:51:22 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 11:51:22 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 11:51:24 --> Severity: Notice --> Undefined variable: plans C:\xampp\htdocs\lottery\application\views\admin\dashboard\plans.php 65
ERROR - 2021-02-27 11:51:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\lottery\application\views\admin\dashboard\plans.php 65
ERROR - 2021-02-27 12:41:04 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 12:41:04 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 12:41:04 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 12:41:11 --> Severity: Notice --> Undefined variable: plans C:\xampp\htdocs\lottery\application\views\admin\dashboard\plans.php 65
ERROR - 2021-02-27 12:41:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\lottery\application\views\admin\dashboard\plans.php 65
ERROR - 2021-02-27 08:41:16 --> 404 Page Not Found: Userdashboard/index
ERROR - 2021-02-27 08:41:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 08:41:35 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 08:41:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 08:41:37 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 08:41:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 12:41:45 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 12:41:45 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 12:41:45 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 12:41:53 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 12:41:53 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 12:41:53 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 12:41:54 --> Severity: Notice --> Undefined variable: plans C:\xampp\htdocs\lottery\application\views\admin\dashboard\plans.php 65
ERROR - 2021-02-27 12:41:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\lottery\application\views\admin\dashboard\plans.php 65
ERROR - 2021-02-27 12:41:56 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 12:41:56 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 12:41:56 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 12:43:29 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 12:43:29 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 12:43:29 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 12:45:13 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 12:45:13 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 12:45:13 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 12:45:42 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-27 12:45:42 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-27 12:45:42 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-27 12:47:03 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\userindex.php 31
ERROR - 2021-02-27 12:47:03 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\userindex.php 46
ERROR - 2021-02-27 12:47:03 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\userindex.php 61
ERROR - 2021-02-27 12:47:22 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\userindex.php 31
ERROR - 2021-02-27 12:47:22 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\userindex.php 46
ERROR - 2021-02-27 12:47:22 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\userindex.php 61
ERROR - 2021-02-27 12:48:10 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\userindex.php 46
ERROR - 2021-02-27 12:48:10 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\userindex.php 61
ERROR - 2021-02-27 12:48:51 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\userindex.php 60
ERROR - 2021-02-27 08:50:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 08:52:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 08:53:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 08:54:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 08:54:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 09:01:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 09:01:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 09:01:29 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 09:02:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 09:02:22 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 09:06:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 09:07:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 09:07:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 09:07:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 09:08:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 09:08:08 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 09:12:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 09:12:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 09:13:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 09:14:37 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 09:15:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 09:21:41 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 09:21:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:08:49 --> Severity: Notice --> Undefined property: Userdashboard::$paypal_lib C:\xampp\htdocs\lottery\application\controllers\admin\Userdashboard.php 50
ERROR - 2021-02-27 14:08:49 --> Severity: error --> Exception: Call to a member function add_field() on null C:\xampp\htdocs\lottery\application\controllers\admin\Userdashboard.php 50
ERROR - 2021-02-27 11:08:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 11:13:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Payment C:\xampp\htdocs\lottery\system\core\Loader.php 348
ERROR - 2021-02-27 11:14:37 --> Severity: error --> Exception: C:\xampp\htdocs\lottery\application\models/Payment_model.php exists, but doesn't declare class Payment_model C:\xampp\htdocs\lottery\system\core\Loader.php 340
ERROR - 2021-02-27 11:19:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 11:19:28 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 11:21:01 --> Severity: Notice --> Undefined property: CI_Loader::$general_settings C:\xampp\htdocs\lottery\application\views\admin\includes\userheader.php 7
ERROR - 2021-02-27 11:21:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\lottery\application\views\admin\includes\userheader.php 7
ERROR - 2021-02-27 11:21:01 --> Could not find the language line "home"
ERROR - 2021-02-27 11:21:01 --> Could not find the language line "logout"
ERROR - 2021-02-27 11:21:01 --> Severity: Notice --> Undefined property: CI_Loader::$general_settings C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 5
ERROR - 2021-02-27 11:21:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 5
ERROR - 2021-02-27 11:21:01 --> Severity: Notice --> Undefined property: CI_Loader::$general_settings C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 6
ERROR - 2021-02-27 11:21:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 6
ERROR - 2021-02-27 11:24:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 11:32:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:06:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:11:00 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 13:20:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:21:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:51:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-27 12:51:33 --> Unable to connect to the database
ERROR - 2021-02-27 12:51:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-27 12:51:41 --> Unable to connect to the database
ERROR - 2021-02-27 13:34:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 13:53:30 --> Severity: Notice --> Trying to get property 'package' of non-object C:\xampp\htdocs\lottery\application\controllers\Home.php 83
ERROR - 2021-02-27 14:05:44 --> 404 Page Not Found: A/index
ERROR - 2021-02-27 14:06:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 14:06:59 --> 404 Page Not Found: Home/play
ERROR - 2021-02-27 14:07:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:07:32 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 14:10:06 --> 404 Page Not Found: admin/Home/index
ERROR - 2021-02-27 14:10:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 14:29:59 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\lottery\application\controllers\Home.php 177
ERROR - 2021-02-27 14:31:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 14:38:34 --> Severity: Notice --> Undefined variable: plans C:\xampp\htdocs\lottery\application\views\front\plans.php 65
ERROR - 2021-02-27 14:38:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\lottery\application\views\front\plans.php 65
ERROR - 2021-02-27 14:38:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:38:35 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 14:38:58 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:39:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:39:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:39:52 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 14:41:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:42:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:42:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 14:43:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:43:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:44:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:45:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:46:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:46:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:46:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:46:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:46:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:46:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:47:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:47:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:48:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:48:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:49:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:50:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:51:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:52:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:52:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:53:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:53:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:54:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:54:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:55:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:56:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:57:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:58:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 14:58:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:02:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:02:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:02:09 --> 404 Page Not Found: Home/play
ERROR - 2021-02-27 15:03:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:03:23 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 15:03:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:03:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:04:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:10:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:10:55 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 15:11:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:11:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:12:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:15:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:15:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:15:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:16:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:17:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:17:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:18:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 15:18:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:20:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:25:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:25:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:26:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:27:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:28:12 --> 404 Page Not Found: Howitworks/index
ERROR - 2021-02-27 15:28:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:28:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:28:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:30:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-27 15:30:55 --> Unable to connect to the database
ERROR - 2021-02-27 15:31:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 15:31:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:31:11 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 15:31:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:31:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:31:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:32:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:32:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:34:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:35:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 15:35:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:35:36 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 15:35:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:37:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:37:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:37:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:39:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 15:40:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 15:42:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:42:17 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 15:42:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:42:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:42:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:42:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:42:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:50:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:52:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:55:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:57:05 --> 404 Page Not Found: Playgame/index
ERROR - 2021-02-27 15:57:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 15:57:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 15:57:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:57:29 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 15:59:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:59:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:59:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 15:59:51 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 16:05:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:06:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:06:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 16:07:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:27:58 --> Severity: error --> Exception: Cannot use object of type mysqli as array C:\xampp\htdocs\lottery\application\models\admin\Crud_model.php 19
ERROR - 2021-02-27 16:28:02 --> Severity: error --> Exception: Cannot use object of type mysqli as array C:\xampp\htdocs\lottery\application\models\admin\Crud_model.php 19
ERROR - 2021-02-27 16:28:40 --> Severity: Notice --> Undefined property: mysqli::$package C:\xampp\htdocs\lottery\application\models\admin\Crud_model.php 19
ERROR - 2021-02-27 16:28:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:29:38 --> Severity: Notice --> Trying to get property 'package' of non-object C:\xampp\htdocs\lottery\application\models\admin\Crud_model.php 19
ERROR - 2021-02-27 16:29:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:30:16 --> Severity: Notice --> Undefined property: mysqli::$package C:\xampp\htdocs\lottery\application\models\admin\Crud_model.php 19
ERROR - 2021-02-27 16:30:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:30:46 --> Severity: Notice --> Trying to get property 'package' of non-object C:\xampp\htdocs\lottery\application\models\admin\Crud_model.php 19
ERROR - 2021-02-27 16:30:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:30:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:31:39 --> Severity: Notice --> Undefined variable: package_name C:\xampp\htdocs\lottery\application\views\front\dashboard.php 19
ERROR - 2021-02-27 16:31:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:32:00 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\lottery\application\views\front\dashboard.php 19
ERROR - 2021-02-27 16:32:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:34:23 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\lottery\application\controllers\Home.php 76
ERROR - 2021-02-27 16:37:36 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\lottery\application\views\front\dashboard.php 17
ERROR - 2021-02-27 16:37:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\lottery\application\views\front\dashboard.php 17
ERROR - 2021-02-27 16:37:36 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\lottery\application\views\front\dashboard.php 22
ERROR - 2021-02-27 16:37:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\lottery\application\views\front\dashboard.php 22
ERROR - 2021-02-27 16:37:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:37:36 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 16:37:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\lottery\application\controllers\Home.php 80
ERROR - 2021-02-27 16:38:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:38:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:38:56 --> Severity: Notice --> Undefined index: no_tickets C:\xampp\htdocs\lottery\application\views\front\dashboard.php 27
ERROR - 2021-02-27 16:38:56 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:39:13 --> Severity: Notice --> Undefined index: no_of_ticket C:\xampp\htdocs\lottery\application\views\front\dashboard.php 27
ERROR - 2021-02-27 16:39:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:39:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:41:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:44:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:44:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 16:44:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:06:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 18:06:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:07:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:08:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:09:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:09:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:09:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:11:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:11:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:11:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:12:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:13:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:13:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:15:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:23:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:23:23 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 18:23:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:23:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\lottery\application\controllers\Home.php 142
ERROR - 2021-02-27 18:24:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:24:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:25:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:27:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:29:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:29:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:31:26 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\lottery\application\controllers\Home.php 239
ERROR - 2021-02-27 18:31:28 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\lottery\system\libraries\Email.php 1902
ERROR - 2021-02-27 18:31:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:33:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:33:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:33:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:33:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:33:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 18:34:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:34:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:39:25 --> Severity: Notice --> Undefined property: Home::$paypal_lib C:\xampp\htdocs\lottery\application\controllers\Home.php 169
ERROR - 2021-02-27 18:39:25 --> Severity: error --> Exception: Call to a member function add_field() on null C:\xampp\htdocs\lottery\application\controllers\Home.php 169
ERROR - 2021-02-27 18:42:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:42:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:43:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:43:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:44:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:44:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:44:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:45:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 18:45:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:53:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:53:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 12:53:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:55:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:56:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 12:56:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:56:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:56:09 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 12:56:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:56:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:56:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:56:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:56:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:57:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:57:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:57:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:57:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:57:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:57:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 12:57:29 --> Severity: Notice --> Undefined index: email /home/quetjoxq/lottery.quetech.info/application/controllers/Home.php 239
ERROR - 2021-02-27 13:00:28 --> Severity: Notice --> Undefined index: email /home/quetjoxq/lottery.quetech.info/application/controllers/Home.php 239
ERROR - 2021-02-27 13:00:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:05:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 13:06:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:10:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:10:13 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 13:18:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:18:46 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 13:18:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 13:18:56 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:19:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:19:06 --> Severity: Notice --> Undefined index: email /home/quetjoxq/lottery.quetech.info/application/controllers/Home.php 239
ERROR - 2021-02-27 13:19:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:19:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:19:48 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-27 13:19:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:19:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:21:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:21:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 13:21:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:21:59 --> 404 Page Not Found: Home/admin
ERROR - 2021-02-27 13:22:11 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 13:26:34 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-27 13:26:44 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 13:27:15 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-27 13:27:42 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-27 13:29:08 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-27 13:29:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 13:30:01 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-27 13:30:09 --> 404 Page Not Found: admin/Packages/add
ERROR - 2021-02-27 13:30:25 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 13:30:47 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-27 13:31:31 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-27 13:35:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 13:36:34 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 13:41:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 13:41:06 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 13:41:23 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 13:43:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 20:19:20 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 20:19:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-27 21:51:03 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-27 21:51:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 21:51:36 --> 404 Page Not Found: Rules/index
ERROR - 2021-02-27 21:51:43 --> 404 Page Not Found: Helphtml/index
ERROR - 2021-02-27 21:51:47 --> 404 Page Not Found: Winnershtml/index
ERROR - 2021-02-27 21:51:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 21:52:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 21:52:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 21:58:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-27 21:58:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
