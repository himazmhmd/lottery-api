<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-18 08:11:25 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-18 08:15:35 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:35 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:35 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:35 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:40 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:40 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:40 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:40 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:42 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:42 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 08:15:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-18 15:47:35 --> 404 Page Not Found: Assets/dist
