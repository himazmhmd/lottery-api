<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-16 05:22:25 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 05:22:42 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 05:26:16 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 05:26:22 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 05:26:24 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 06:15:35 --> Severity: error --> Exception: syntax error, unexpected 'are' (T_STRING), expecting ')' C:\wamp64\www\ci_role_permissions\application\controllers\admin\Users.php 43
ERROR - 2019-07-16 06:32:57 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:32:57 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:32:57 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:32:57 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:32:57 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:32:57 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:32:57 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:12 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:12 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:33:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:34:27 --> 404 Page Not Found: Dist/img
ERROR - 2019-07-16 06:35:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:50 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:50 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:50 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:50 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:51 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:51 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:51 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:51 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:51 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:35:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:36:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:36:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:36:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:36:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:36:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:36:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:36:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:36:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:36:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:39:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:39:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:39:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:39:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:39:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:39:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:39:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:39:32 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:39:32 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:39:32 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:39:32 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:40:03 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:40:03 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:40:03 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:40:03 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:40:35 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:40:35 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:40:36 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:40:36 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:41:12 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2019-07-16 06:41:22 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 06:41:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:41:22 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:41:22 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 06:41:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:41:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:41:22 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 06:41:23 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 06:41:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:41:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:41:23 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 06:41:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 06:42:00 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2019-07-16 06:42:00 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2019-07-16 07:01:01 --> 404 Page Not Found: /index
ERROR - 2019-07-16 07:03:02 --> 404 Page Not Found: admin//index
ERROR - 2019-07-16 07:03:06 --> 404 Page Not Found: admin//index
ERROR - 2019-07-16 07:03:59 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 07:04:05 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 07:04:11 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 07:10:23 --> Severity: error --> Exception: syntax error, unexpected '{', expecting function (T_FUNCTION) C:\wamp64\www\ci_role_permissions\application\libraries\Functions.php 10
ERROR - 2019-07-16 07:11:01 --> 404 Page Not Found: Access_denied/index
ERROR - 2019-07-16 07:12:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 07:12:38 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 07:12:59 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 07:15:18 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 07:15:40 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 07:20:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 07:23:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 07:23:20 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 07:23:44 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 07:26:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:02 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:05 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:05 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:05 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:09 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:09 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:09 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:09 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:18 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:18 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:18 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:19 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:26:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:28:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:28:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:28:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:28:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:28:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:28:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:34:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:34:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:34:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:34:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:34:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:34:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:36:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:36:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:36:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:36:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:36:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:36:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:44 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:44 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:55 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:55 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:55 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:55 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:59 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:59 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:40:59 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:41:00 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:41:02 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 07:41:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:41:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:41:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:41:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:48:15 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:48:15 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:51:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:51:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:51:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:51:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:51:38 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:51:39 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:52:35 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:52:36 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:52:40 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:52:40 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:52:41 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:52:41 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:52:42 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 07:52:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:54:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:54:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:54:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:54:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:55:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 07:56:31 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 07:56:34 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:34 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:34 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:34 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:34 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:46 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:46 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:00:48 --> 404 Page Not Found: Public/dist
ERROR - 2019-07-16 08:02:04 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:02:05 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:02:17 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:02:17 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:02:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:02:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:02:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:02:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:02:25 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 08:02:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:06:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:06:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:07:10 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2019-07-16 08:07:11 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2019-07-16 08:26:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 08:32:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:32:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:32:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:32:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:33:40 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:33:48 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:35:27 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:35:34 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:36:28 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:36:34 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:36:40 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:44:33 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:44:38 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:44:49 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:46:49 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 08:53:19 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:53:51 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:54:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:54:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:54:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:54:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 08:55:53 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 08:56:01 --> 404 Page Not Found: admin/Example/index
ERROR - 2019-07-16 08:57:14 --> 404 Page Not Found: Invoices/index
ERROR - 2019-07-16 08:58:43 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:58:57 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:59:02 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 08:59:40 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 09:00:09 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 09:03:09 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 09:05:17 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 09:05:48 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 09:11:08 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 09:11:38 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 09:29:53 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 09:30:15 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 09:31:31 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 09:31:55 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 09:35:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 09:36:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 09:37:22 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 09:37:29 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 09:38:37 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 09:38:37 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 09:38:37 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 09:38:37 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 09:38:42 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 09:40:25 --> 404 Page Not Found: Dist/img
ERROR - 2019-07-16 00:42:29 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 00:42:29 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 00:42:29 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 00:42:29 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 00:42:29 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 00:42:39 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 00:42:39 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 00:42:39 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 00:42:39 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 00:42:39 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 09:43:31 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 46
ERROR - 2019-07-16 00:52:13 --> Severity: Notice --> Undefined index: access C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 09:53:18 --> Severity: Compile Error --> Cannot use [] for reading C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 00:55:17 --> Severity: Notice --> Undefined variable: key C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 00:55:17 --> Severity: Notice --> Undefined index:  C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 00:56:49 --> Severity: Notice --> Array to string conversion C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 10:12:43 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 01:12:45 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:12:45 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:12:45 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:12:45 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:12:45 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:12:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 10:14:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 10:14:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 10:14:43 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:15:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 10:16:51 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 10:16:58 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:18:23 --> Severity: error --> Exception: syntax error, unexpected 'print_r' (T_STRING), expecting ';' or '{' C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 10:18:54 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ';' or '{' C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 10:19:31 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting ';' or '{' C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 49
ERROR - 2019-07-16 01:20:06 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 47
ERROR - 2019-07-16 01:22:44 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 41
ERROR - 2019-07-16 01:22:44 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:22:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:22:49 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 41
ERROR - 2019-07-16 01:22:49 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:22:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:22:52 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 41
ERROR - 2019-07-16 01:22:52 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:22:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 10:25:00 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 01:26:27 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 41
ERROR - 2019-07-16 01:26:27 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:26:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 43
ERROR - 2019-07-16 01:28:41 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:28:41 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:28:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:28:45 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:28:45 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:28:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:28:50 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:28:50 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:28:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 10:30:11 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: admin C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: admin C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:30:52 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:30:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:31:37 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:31:37 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:31:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:31:41 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:31:41 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:31:46 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:31:46 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:31:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:33:43 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:33:43 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:33:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 10:33:43 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 10:35:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 01:35:12 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:35:12 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:35:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:35:16 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:35:16 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:35:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 01:35:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 44
ERROR - 2019-07-16 10:35:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:35:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:35:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:35:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 01:36:48 --> Severity: Notice --> Undefined index: admin C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:36:48 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:36:48 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:36:48 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:36:48 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:36:48 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:36:48 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 01:36:48 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 42
ERROR - 2019-07-16 10:37:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:37:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:37:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:37:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:37:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:37:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:37:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:37:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 10:39:15 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:39:29 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:40:00 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 10:40:09 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:41:35 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:47:49 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:51:33 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:51:44 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 10:56:15 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:57:10 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 10:57:27 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 10:57:44 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 11:02:56 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 02:03:01 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 46
ERROR - 2019-07-16 02:03:01 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 46
ERROR - 2019-07-16 02:03:01 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 46
ERROR - 2019-07-16 02:03:01 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 46
ERROR - 2019-07-16 02:03:01 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 46
ERROR - 2019-07-16 02:03:01 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 46
ERROR - 2019-07-16 02:03:01 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 46
ERROR - 2019-07-16 02:05:28 --> Severity: Notice --> Undefined variable: module C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 32
ERROR - 2019-07-16 02:05:28 --> Severity: Notice --> Undefined index:  C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 32
ERROR - 2019-07-16 02:05:28 --> Severity: Notice --> Undefined variable: module C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 34
ERROR - 2019-07-16 02:05:29 --> Severity: Notice --> Undefined variable: module C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 32
ERROR - 2019-07-16 02:05:29 --> Severity: Notice --> Undefined index:  C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 32
ERROR - 2019-07-16 02:05:29 --> Severity: Notice --> Undefined variable: module C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 34
ERROR - 2019-07-16 02:06:44 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:06:44 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:06:44 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:06:44 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:06:44 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:06:44 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:06:44 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 11:07:39 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 53
ERROR - 2019-07-16 02:09:05 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:09:05 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:09:05 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:09:05 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:09:05 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:09:05 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:09:05 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 11:11:06 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 02:11:08 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:11:08 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:11:08 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:11:08 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:11:08 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:11:08 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:11:08 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:22 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:22 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:22 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:22 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:22 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:22 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:22 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 11:14:38 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 02:14:42 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:42 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:42 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:42 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:42 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:42 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:42 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:55 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:55 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:55 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:55 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:55 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:55 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:14:55 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:09 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:09 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:09 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:09 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:09 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:09 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:09 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:45 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:45 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:45 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:45 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:45 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:45 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:45 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:15:57 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 11:15:57 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 02:16:00 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:16:00 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:16:00 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:16:00 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:16:00 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:16:00 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 02:16:00 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 45
ERROR - 2019-07-16 11:17:13 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 11:18:06 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 11:19:04 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 58
ERROR - 2019-07-16 11:20:08 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 11:22:31 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 11:23:03 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 11:23:45 --> 404 Page Not Found: Assets/dist
ERROR - 2019-07-16 11:23:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 11:24:42 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 11:24:47 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 11:24:47 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 11:24:48 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 11:24:48 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 11:24:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2019-07-16 11:24:56 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 02:25:27 --> Severity: Notice --> Undefined index: admin C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Notice --> Undefined index: admin C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Notice --> Undefined index: admin_roles C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Notice --> Undefined index: users C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Notice --> Undefined index: example C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Notice --> Undefined index: invoices C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Notice --> Undefined index: joins C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Notice --> Undefined index: export C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Notice --> Undefined index: general_settings C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 02:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\ci_role_permissions\application\libraries\Rbac.php 48
ERROR - 2019-07-16 11:26:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 11:26:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 11:26:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 11:26:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-07-16 21:33:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Profile_model C:\wamp64\www\ci_role_permissions\system\core\Loader.php 348
