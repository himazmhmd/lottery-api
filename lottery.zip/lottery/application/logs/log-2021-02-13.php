<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-13 11:50:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ci_adminlite_2020' C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-13 11:50:16 --> Unable to connect to the database
ERROR - 2021-02-13 11:51:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ci_adminlite_2020' C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-13 11:51:23 --> Unable to connect to the database
ERROR - 2021-02-13 11:51:44 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-13 11:52:01 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-13 11:52:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-13 11:54:00 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-13 11:54:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 1984
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 1985
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 1987
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 1988
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2048
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2049
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2051
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2052
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2235
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2236
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2238
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2239
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2788
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2788
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2789
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2789
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2789
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2791
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2792
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2794
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2795
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2795
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2797
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2797
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2798
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2798
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2798
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 2798
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4137
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4137
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4138
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4140
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4140
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4141
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4143
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4143
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4143
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 4144
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8362
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8362
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8362
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8362
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8362
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8363
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8363
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8364
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8364
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8364
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8364
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8364
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 8364
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21551
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21553
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21557
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21562
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21567
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21596
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21596
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21597
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21599
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21599
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21600
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21602
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21602
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21602
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 21603
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25058
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25059
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25059
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25059
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25508
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25508
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25509
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25509
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25509
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25514
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25514
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25515
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25515
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25515
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25515
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25517
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25518
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25528
ERROR - 2021-02-13 00:55:07 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25528
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25529
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25529
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25529
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25535
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25535
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25536
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25536
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25536
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25536
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25538
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 25539
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 28239
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 28256
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 28275
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 28311
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 28311
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32438
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32438
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32438
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32438
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32439
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32439
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32439
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32440
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32440
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32440
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32440
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32441
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32441
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32441
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32441
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32441
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32442
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32442
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32442
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32442
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32442
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32443
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32443
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32443
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32443
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32443
ERROR - 2021-02-13 00:55:08 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated C:\xampp\htdocs\lottery\application\helpers\mpdf\mpdf.php 32443
ERROR - 2021-02-13 11:55:08 --> 404 Page Not Found: Public/plugins
ERROR - 2021-02-13 11:55:08 --> 404 Page Not Found: Public/plugins
ERROR - 2021-02-13 11:55:08 --> 404 Page Not Found: Public/plugins
ERROR - 2021-02-13 11:55:08 --> 404 Page Not Found: Public/plugins
ERROR - 2021-02-13 11:57:47 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-13 12:00:20 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2021-02-13 12:00:22 --> 404 Page Not Found: admin/Mailbox/compose.html
ERROR - 2021-02-13 12:08:37 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-13 12:08:41 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-13 12:17:07 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-13 12:17:11 --> 404 Page Not Found: Public/bootstrap
