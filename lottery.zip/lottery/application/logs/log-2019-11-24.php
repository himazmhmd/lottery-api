<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-24 19:44:05 --> Query error: Table 'ci_roles_permissions.admin_roles' doesn't exist - Invalid query: SELECT *
FROM `admin_roles`
ERROR - 2019-11-24 20:00:32 --> Severity: Notice --> Undefined index: link F:\xampp\htdocs\ozient\adminlite\application\views\admin\includes\_sidebar.php 62
ERROR - 2019-11-24 20:00:32 --> Severity: Notice --> Undefined index: link F:\xampp\htdocs\ozient\adminlite\application\views\admin\includes\_sidebar.php 62
ERROR - 2019-11-24 20:00:32 --> Severity: Notice --> Undefined index: link F:\xampp\htdocs\ozient\adminlite\application\views\admin\includes\_sidebar.php 62
ERROR - 2019-11-24 20:00:36 --> Severity: Notice --> Undefined index: link F:\xampp\htdocs\ozient\adminlite\application\views\admin\includes\_sidebar.php 62
ERROR - 2019-11-24 20:00:36 --> Severity: Notice --> Undefined index: link F:\xampp\htdocs\ozient\adminlite\application\views\admin\includes\_sidebar.php 62
ERROR - 2019-11-24 20:00:36 --> Severity: Notice --> Undefined index: link F:\xampp\htdocs\ozient\adminlite\application\views\admin\includes\_sidebar.php 62
ERROR - 2019-11-24 21:20:24 --> Severity: Notice --> Undefined variable: files F:\xampp\htdocs\ozient\adminlite\application\views\admin\examples\file_upload.php 125
ERROR - 2019-11-24 21:23:19 --> Severity: Notice --> Undefined variable: files F:\xampp\htdocs\ozient\adminlite\application\views\admin\examples\file_upload.php 125
ERROR - 2019-11-24 21:24:02 --> Severity: Notice --> Undefined variable: files F:\xampp\htdocs\ozient\adminlite\application\views\admin\examples\file_upload.php 125
ERROR - 2019-11-24 21:24:02 --> Severity: Notice --> Undefined variable: files F:\xampp\htdocs\ozient\adminlite\application\views\admin\examples\file_upload.php 125
ERROR - 2019-11-24 21:24:02 --> Severity: Notice --> Undefined variable: files F:\xampp\htdocs\ozient\adminlite\application\views\admin\examples\file_upload.php 125
ERROR - 2019-11-24 21:24:03 --> Severity: Notice --> Undefined variable: files F:\xampp\htdocs\ozient\adminlite\application\views\admin\examples\file_upload.php 125
ERROR - 2019-11-24 21:24:04 --> Severity: Notice --> Undefined variable: files F:\xampp\htdocs\ozient\adminlite\application\views\admin\examples\file_upload.php 125
ERROR - 2019-11-24 21:27:12 --> Severity: Notice --> Undefined variable: files F:\xampp\htdocs\ozient\adminlite\application\views\admin\examples\file_upload.php 125
ERROR - 2019-11-24 21:27:36 --> Severity: Notice --> Undefined variable: files F:\xampp\htdocs\ozient\adminlite\application\views\admin\examples\file_upload.php 125
