<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-27 00:47:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 00:54:35 --> 404 Page Not Found: Upphp/index
ERROR - 2021-03-27 02:46:31 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-27 02:46:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-27 02:46:49 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-27 02:47:09 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-27 04:28:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 04:28:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-27 04:28:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 04:28:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 04:28:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 04:28:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 04:30:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 06:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-27 06:05:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 06:05:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-27 10:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-27 10:56:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 10:56:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 21:00:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 21:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-27 21:00:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 21:01:58 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-27 23:50:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 23:50:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-27 23:51:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
