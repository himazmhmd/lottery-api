<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-02 11:32:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 11:32:55 --> Unable to connect to the database
ERROR - 2021-03-02 11:32:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 11:33:30 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 11:33:30 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-02 11:33:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 12:42:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 12:42:12 --> Unable to connect to the database
ERROR - 2021-03-02 12:42:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 12:42:16 --> Unable to connect to the database
ERROR - 2021-03-02 12:42:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 12:43:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 12:43:49 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-02 12:46:58 --> 404 Page Not Found: Paypal/success
ERROR - 2021-03-02 12:47:25 --> 404 Page Not Found: Paypal/success
ERROR - 2021-03-02 12:47:31 --> 404 Page Not Found: Paypal/success
ERROR - 2021-03-02 12:48:23 --> 404 Page Not Found: Paypal/cancel
ERROR - 2021-03-02 12:49:43 --> 404 Page Not Found: Paypal/success
ERROR - 2021-03-02 12:56:29 --> Severity: Notice --> Undefined index: item_number C:\xampp\htdocs\final_lottery\application\controllers\Home.php 188
ERROR - 2021-03-02 12:56:29 --> Severity: Notice --> Undefined index: item_number C:\xampp\htdocs\final_lottery\application\controllers\Home.php 189
ERROR - 2021-03-02 12:56:29 --> Severity: Notice --> Undefined index: tx C:\xampp\htdocs\final_lottery\application\controllers\Home.php 190
ERROR - 2021-03-02 12:56:29 --> Severity: Notice --> Undefined index: amt C:\xampp\htdocs\final_lottery\application\controllers\Home.php 191
ERROR - 2021-03-02 12:56:29 --> Severity: Notice --> Undefined index: cc C:\xampp\htdocs\final_lottery\application\controllers\Home.php 192
ERROR - 2021-03-02 12:56:29 --> Severity: Notice --> Undefined index: st C:\xampp\htdocs\final_lottery\application\controllers\Home.php 193
ERROR - 2021-03-02 13:01:30 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 13:24:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 13:46:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 13:46:25 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-02 13:48:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 13:51:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 13:53:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:07:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:07:18 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-02 14:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 14:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 14:12:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 14:14:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:14:44 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-02 14:14:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:15:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:15:08 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-02 14:15:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:15:42 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:16:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:17:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:19:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:20:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:21:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:21:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:21:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:21:52 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-02 14:22:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:22:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:22:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:23:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:23:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:24:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:24:31 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-02 14:25:00 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-02 14:25:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:27:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-02 14:33:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 14:33:49 --> Unable to connect to the database
ERROR - 2021-03-02 14:33:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 14:33:53 --> Unable to connect to the database
ERROR - 2021-03-02 14:33:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 14:33:59 --> Unable to connect to the database
ERROR - 2021-03-02 14:34:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 14:41:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 14:41:37 --> Unable to connect to the database
ERROR - 2021-03-02 14:41:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 14:41:39 --> Unable to connect to the database
ERROR - 2021-03-02 14:41:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 14:51:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 15:52:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 15:52:02 --> Unable to connect to the database
ERROR - 2021-03-02 15:52:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-03-02 15:52:05 --> Unable to connect to the database
ERROR - 2021-03-02 15:53:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-02 15:53:53 --> 404 Page Not Found: Test/index
