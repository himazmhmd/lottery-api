<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-01 07:36:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 08:11:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 08:18:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 08:22:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 08:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 08:43:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 08:44:26 --> Query error: Duplicate entry 'aafi.ciit@gmail.com' for key 'email' - Invalid query: INSERT INTO `ci_users` (`firstname`, `lastname`, `username`, `email`, `password`, `term`, `card_number`, `exp_month`, `exp_year`, `cvv`) VALUES ('Muhammad ', 'Aafaq', 'Muhammad Aafaq', 'aafi.ciit@gmail.com', '12345', '1', '12345', '5 july', '2022', '11')
ERROR - 2021-03-01 08:58:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 09:05:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:05:15 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 09:11:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:11:50 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 09:11:56 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:12:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:12:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:13:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:13:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:13:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:13:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:14:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 09:14:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:14:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:14:55 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 09:15:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:15:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:15:26 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 09:15:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:18:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 09:32:30 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:35:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 09:35:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 09:35:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 09:35:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 09:35:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:36:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:37:42 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 09:37:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 09:37:42 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 09:37:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 09:37:42 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:38:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:43:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:54:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:55:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:55:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:56:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:56:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 09:59:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:28:27 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 10:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 10:28:27 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 10:28:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 10:28:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:28:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:29:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:30:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:31:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:31:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:32:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:32:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:32:22 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 10:33:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:34:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:35:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:37:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:41:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:44:29 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-01 10:44:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:44:29 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-01 10:49:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:49:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-01 10:49:48 --> 404 Page Not Found: Assets/images
ERROR - 2021-03-01 10:51:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:51:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:56:58 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:57:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:58:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:58:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:00:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:00:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:02:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:02:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:02:23 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 11:02:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:02:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 11:02:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:07:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:07:22 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 11:07:25 --> 404 Page Not Found: Change/index
ERROR - 2021-03-01 11:08:08 --> 404 Page Not Found: Change/index
ERROR - 2021-03-01 11:08:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:08:13 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 11:08:42 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:08:43 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 11:08:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 11:13:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 11:13:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:13:16 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 11:13:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 11:14:06 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 11:14:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 11:14:06 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 11:14:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 11:14:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:14:06 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 11:14:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:20:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:20:03 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 11:20:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 11:24:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 11:24:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 11:24:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:24:39 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 11:25:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:25:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:30:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:32:15 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 11:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 11:32:15 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 11:32:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 11:32:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:32:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:48:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:58:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 11:58:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 11:58:25 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 11:58:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:00:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:01:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:02:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:02:13 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 12:02:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:02:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:02:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 12:02:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 10:18:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 12:12:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:12:50 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 12:13:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:26:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:26:17 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 12:27:42 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:29:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:30:06 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 17
ERROR - 2021-03-01 12:30:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:30:25 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 17
ERROR - 2021-03-01 12:30:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:30:26 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 17
ERROR - 2021-03-01 12:30:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:30:27 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 17
ERROR - 2021-03-01 12:30:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:30:27 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 17
ERROR - 2021-03-01 12:30:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:30:28 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 17
ERROR - 2021-03-01 12:30:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:30:28 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 17
ERROR - 2021-03-01 12:30:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:30:49 --> Severity: Notice --> Trying to get property 'username' of non-object C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 17
ERROR - 2021-03-01 12:30:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:31:17 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 17
ERROR - 2021-03-01 12:31:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:31:35 --> Severity: Notice --> Undefined variable: user_date C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 4
ERROR - 2021-03-01 12:31:35 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 19
ERROR - 2021-03-01 12:31:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:31:42 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 19
ERROR - 2021-03-01 12:31:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:31:43 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 12:32:15 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 19
ERROR - 2021-03-01 12:32:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:32:16 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 12:36:29 --> Severity: error --> Exception: Call to a member function result_array() on array C:\xampp\htdocs\final_lottery\application\controllers\Home.php 100
ERROR - 2021-03-01 12:37:20 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 19
ERROR - 2021-03-01 12:37:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 6
ERROR - 2021-03-01 12:39:32 --> Severity: Warning --> Illegal string offset 'username' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 21
ERROR - 2021-03-01 12:39:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:41:31 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 16
ERROR - 2021-03-01 12:41:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 16
ERROR - 2021-03-01 12:41:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:42:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 16
ERROR - 2021-03-01 12:42:58 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 16
ERROR - 2021-03-01 12:42:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 16
ERROR - 2021-03-01 12:42:58 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:43:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:44:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:44:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:44:58 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:47:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:47:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:48:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:48:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:49:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:49:38 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\final_lottery\application\views\front\account_setting.php 39
ERROR - 2021-03-01 12:49:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:53:10 --> 404 Page Not Found: Edit_settings/58
ERROR - 2021-03-01 12:53:32 --> 404 Page Not Found: Edit_settings/58
ERROR - 2021-03-01 12:53:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:53:55 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 12:53:58 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:53:58 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 12:55:15 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\final_lottery\application\views\front\edit_setting.php 14
ERROR - 2021-03-01 12:55:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\edit_setting.php 14
ERROR - 2021-03-01 12:55:15 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\final_lottery\application\views\front\edit_setting.php 20
ERROR - 2021-03-01 12:55:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\edit_setting.php 20
ERROR - 2021-03-01 12:55:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:55:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:58:24 --> Severity: Notice --> Undefined index: firtname C:\xampp\htdocs\final_lottery\application\views\front\edit_setting.php 23
ERROR - 2021-03-01 12:58:24 --> Severity: Notice --> Undefined index: surname C:\xampp\htdocs\final_lottery\application\views\front\edit_setting.php 27
ERROR - 2021-03-01 12:58:24 --> Severity: Notice --> Undefined index: vcc C:\xampp\htdocs\final_lottery\application\views\front\edit_setting.php 54
ERROR - 2021-03-01 12:58:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 12:59:02 --> Severity: Notice --> Undefined index: vcc C:\xampp\htdocs\final_lottery\application\views\front\edit_setting.php 54
ERROR - 2021-03-01 12:59:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:00:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:00:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:00:31 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:01:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:02:56 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:02:56 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:04:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:04:13 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:10:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:10:47 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 13:10:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:11:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:11:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:11:04 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 13:11:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:11:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:11:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:11:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 13:11:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:11:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:13:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:13:03 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:38:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:38:04 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:38:17 --> 404 Page Not Found: Home/edit_setting
ERROR - 2021-03-01 13:38:38 --> 404 Page Not Found: Home/edit_setting
ERROR - 2021-03-01 13:38:40 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:38:42 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:38:42 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:38:55 --> 404 Page Not Found: Home/www.google-analytics.com
ERROR - 2021-03-01 13:40:01 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:45:03 --> 404 Page Not Found: Home/edit_seeting
ERROR - 2021-03-01 13:45:05 --> 404 Page Not Found: Home/edit_seeting
ERROR - 2021-03-01 13:45:27 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:46:03 --> 404 Page Not Found: Home/edit_setting
ERROR - 2021-03-01 13:46:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 13:46:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:46:51 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 13:46:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:47:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:47:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:47:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:47:32 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 13:47:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:47:35 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 13:47:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:48:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:48:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:49:08 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 13:49:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 13:49:08 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 13:49:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 13:49:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:49:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:49:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 13:49:36 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 14:10:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:10:20 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 14:11:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:11:39 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 14:11:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 14:15:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:15:05 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 14:15:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:15:08 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 14:15:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:15:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:15:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:23:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:23:07 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 14:23:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:23:38 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 14:24:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 14:26:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 14:29:36 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\final_lottery\application\controllers\Home.php 256
ERROR - 2021-03-01 14:30:17 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\final_lottery\application\controllers\Home.php 250
ERROR - 2021-03-01 14:31:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:31:16 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 14:31:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:31:40 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 14:31:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:31:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:31:52 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 14:32:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 14:33:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 14:33:38 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 14:33:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 14:33:38 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 14:33:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 14:33:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:33:39 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 14:33:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:33:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:33:52 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 14:33:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:33:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:34:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:34:01 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 14:34:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:35:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 14:35:52 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 14:35:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 14:35:52 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 14:35:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 14:35:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 15:23:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\final_lottery\application\controllers\Home.php 88
ERROR - 2021-03-01 15:23:19 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 17
ERROR - 2021-03-01 15:23:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 17
ERROR - 2021-03-01 15:23:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 15:23:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 15:23:19 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 15:23:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 18:33:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 18:47:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\final_lottery\application\controllers\Home.php 88
ERROR - 2021-03-01 18:47:18 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 17
ERROR - 2021-03-01 18:47:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 17
ERROR - 2021-03-01 18:47:18 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 18:47:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 18:47:18 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 18:47:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 18:47:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 18:47:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 18:47:27 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 18:47:30 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 18:47:30 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 18:47:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 18:47:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 18:47:35 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 18:47:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\final_lottery\application\controllers\Home.php 88
ERROR - 2021-03-01 18:47:41 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 17
ERROR - 2021-03-01 18:47:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 17
ERROR - 2021-03-01 18:47:41 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 18:47:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 18:47:41 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 18:47:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 18:47:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 18:49:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\final_lottery\application\controllers\Home.php 88
ERROR - 2021-03-01 18:49:16 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 17
ERROR - 2021-03-01 18:49:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 17
ERROR - 2021-03-01 18:49:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 18:49:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 18:49:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 18:49:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 18:49:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 18:50:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 18:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 18:50:16 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 18:50:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 18:50:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:01:40 --> Query error: Not unique table/alias: 'ci_users' - Invalid query: SELECT *
FROM `ci_users`
JOIN `ci_users` ON `ci_users`.`package` = `packages`.`id`
WHERE `ci_usersid` = '58'
ERROR - 2021-03-01 19:02:19 --> Query error: Not unique table/alias: 'ci_users' - Invalid query: SELECT *
FROM `ci_users`
JOIN `ci_users` ON `ci_users`.`package` = `packages`.`id`
WHERE `ci_users`.`id` = '58'
ERROR - 2021-03-01 19:02:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\final_lottery\system\database\DB_query_builder.php 2442
ERROR - 2021-03-01 19:02:55 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `packages`
WHERE `id` = Array
ERROR - 2021-03-01 19:03:59 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:03:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:03:59 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:03:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:03:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:04:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\final_lottery\system\database\DB_query_builder.php 2442
ERROR - 2021-03-01 19:04:48 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `packages`
WHERE `id` = Array
ERROR - 2021-03-01 19:06:06 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:06:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:06:06 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:06:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:06:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:07:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:08:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:14:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:15:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:15:38 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\final_lottery\system\database\DB_query_builder.php 2442
ERROR - 2021-03-01 19:15:38 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `packages`
WHERE `id` = Array
ERROR - 2021-03-01 19:19:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\final_lottery\system\database\DB_query_builder.php 2442
ERROR - 2021-03-01 19:19:19 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `packages`
WHERE `id` = Array
ERROR - 2021-03-01 19:20:23 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\final_lottery\system\database\DB_query_builder.php 2442
ERROR - 2021-03-01 19:20:23 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `packages`
WHERE `id` = Array
ERROR - 2021-03-01 19:21:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\final_lottery\system\database\DB_query_builder.php 2442
ERROR - 2021-03-01 19:21:29 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `packages`
WHERE `id` = Array
ERROR - 2021-03-01 19:24:28 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:25:00 --> Severity: Notice --> Undefined index: no_of_ticket C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:25:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:25:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:26:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:26:48 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:26:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:26:50 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:26:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:26:51 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:26:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:26:52 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:26:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:26:53 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:26:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:26:54 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:26:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:26:56 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:26:56 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:27:49 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:27:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:27:50 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:27:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:27:51 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:27:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:27:52 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:27:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:27:53 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 84
ERROR - 2021-03-01 19:27:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:28:59 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:28:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:00 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:01 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:04 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:06 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:08 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:10 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:11 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:12 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:13 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:14 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:15 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:15 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:16 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:17 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:18 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:19 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:20 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:21 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:22 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:23 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:24 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:29:25 --> Severity: Warning --> Illegal string offset 'id' C:\xampp\htdocs\final_lottery\application\controllers\Home.php 85
ERROR - 2021-03-01 19:29:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:41:56 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:41:56 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:41:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:41:57 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 19:42:24 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:42:24 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:42:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:42:37 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:42:37 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:42:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:43:31 --> Severity: Notice --> Undefined index: package_name C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:43:32 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:43:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:44:02 --> Severity: Notice --> Undefined index: package_name C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:44:02 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:44:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:45:37 --> Severity: Notice --> Undefined index: package_name C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:45:37 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:45:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:46:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.`no_of_tickets`
FROM `ci_users`
LEFT JOIN `packages` ON `ci_users`.`package`...' at line 1 - Invalid query: SELECT `packages`.`id packages`.`title` `packages`.`no_of_tickets`
FROM `ci_users`
LEFT JOIN `packages` ON `ci_users`.`package` = `packages`.`id`
WHERE `ci_users`.`id` = '58'
ERROR - 2021-03-01 19:46:46 --> Severity: Notice --> Undefined index: package_name C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:46:46 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:46:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:47:28 --> Severity: Notice --> Undefined index: no_of_tickets C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 27
ERROR - 2021-03-01 19:47:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:47:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:48:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:48:04 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 19:48:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:48:18 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 19:48:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:48:32 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 19:51:48 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 63
ERROR - 2021-03-01 19:52:04 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 19:52:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:52:05 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 19:53:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:53:42 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:53:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:53:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:53:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:56:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:56:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:56:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:56:45 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 19:56:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:57:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:58:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 19:58:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 20:07:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:07:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:08:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:09:00 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 24
ERROR - 2021-03-01 20:09:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:13:04 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 60
ERROR - 2021-03-01 20:13:12 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 21
ERROR - 2021-03-01 20:13:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:13:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:14:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:14:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:14:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:14:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:14:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:14:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:15:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:15:54 --> Severity: Notice --> Trying to get property 'title' of non-object C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 24
ERROR - 2021-03-01 20:15:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:16:46 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 24
ERROR - 2021-03-01 20:16:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:17:08 --> Severity: Notice --> Trying to get property 'title' of non-object C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 24
ERROR - 2021-03-01 20:17:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:17:17 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 24
ERROR - 2021-03-01 20:17:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:20:19 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 24
ERROR - 2021-03-01 20:20:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:21:22 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 22
ERROR - 2021-03-01 20:21:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:21:23 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 22
ERROR - 2021-03-01 20:21:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:22:34 --> Severity: Warning --> Illegal string offset 'title' C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 22
ERROR - 2021-03-01 20:22:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:23:03 --> Severity: Warning --> Illegal string offset 'package' C:\xampp\htdocs\final_lottery\application\views\front\dashboard.php 22
ERROR - 2021-03-01 20:23:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:28:12 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-01 20:28:31 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-01 20:29:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:32:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:37:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:37:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:37:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:37:24 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 20:37:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:37:38 --> Severity: Notice --> Trying to get property 'title' of non-object C:\xampp\htdocs\final_lottery\application\models\admin\Crud_model.php 14
ERROR - 2021-03-01 20:37:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:38:10 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::result_row() C:\xampp\htdocs\final_lottery\application\models\admin\Crud_model.php 14
ERROR - 2021-03-01 20:38:27 --> Severity: Notice --> Trying to get property 'title' of non-object C:\xampp\htdocs\final_lottery\application\models\admin\Crud_model.php 14
ERROR - 2021-03-01 20:38:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:41:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:43:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:43:15 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 20:43:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:43:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:43:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:46:34 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:47:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:47:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:47:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:47:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:47:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:48:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 20:50:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:50:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:51:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:52:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:52:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:52:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:54:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:54:15 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 20:54:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:54:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 20:54:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:56:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:56:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:56:18 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 20:56:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:56:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:56:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:56:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 20:57:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 22:01:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-01 22:01:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 22:01:44 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-01 22:01:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 22:01:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 22:01:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 22:02:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 22:02:02 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-01 22:02:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 22:02:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-01 22:02:14 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-01 22:02:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
