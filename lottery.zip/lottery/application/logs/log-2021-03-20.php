<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-20 06:57:08 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:09 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 15:57:09 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:09 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 15:57:10 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:13 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:13 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 15:57:13 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-20 06:57:16 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:17 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 15:57:18 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:18 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:21 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-20 06:57:26 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-20 06:57:35 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-20 06:57:36 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-20 06:57:39 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-20 06:57:41 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:44 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-20 06:57:44 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:56 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-20 06:57:56 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:56 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-20 06:57:56 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:58 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-20 06:57:58 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:57:58 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-20 06:57:58 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:58:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-20 06:58:14 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:58:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-20 06:58:21 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-20 06:58:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-20 06:58:25 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
