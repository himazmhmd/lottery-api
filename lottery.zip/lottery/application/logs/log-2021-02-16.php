<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-16 11:03:39 --> 404 Page Not Found: Assets/dist
