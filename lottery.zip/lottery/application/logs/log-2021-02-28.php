<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-28 09:03:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:03:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-28 09:04:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:04:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:05:24 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-28 09:08:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:09:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:09:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:10:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:11:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:11:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:12:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:13:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:13:18 --> Severity: Notice --> Undefined variable: row /home/quetjoxq/lottery.quetech.info/application/views/front/dashboard.php 21
ERROR - 2021-02-28 09:13:18 --> Severity: Notice --> Undefined variable: row /home/quetjoxq/lottery.quetech.info/application/views/front/dashboard.php 27
ERROR - 2021-02-28 09:13:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:13:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:39:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:39:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-28 09:40:04 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 09:40:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-28 13:54:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 13:54:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-28 20:07:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'final_lotetery' C:\xampp\htdocs\final_lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-28 20:07:22 --> Unable to connect to the database
ERROR - 2021-02-28 20:07:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-28 20:08:11 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-28 20:10:58 --> 404 Page Not Found: Howitworks/index
ERROR - 2021-02-28 20:19:04 --> 404 Page Not Found: Home/winner
ERROR - 2021-02-28 20:32:22 --> 404 Page Not Found: Home/winners
ERROR - 2021-02-28 20:36:11 --> Severity: Notice --> Undefined variable: plans C:\xampp\htdocs\final_lottery\application\views\front\plans.php 65
ERROR - 2021-02-28 20:36:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\final_lottery\application\views\front\plans.php 65
ERROR - 2021-02-28 20:36:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 20:36:12 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-28 20:36:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 20:36:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 20:45:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-28 20:48:09 --> 404 Page Not Found: Helphtml/index
ERROR - 2021-02-28 20:51:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-28 20:52:42 --> 404 Page Not Found: Helphtml/index
ERROR - 2021-02-28 20:53:12 --> 404 Page Not Found: Home/help
ERROR - 2021-02-28 20:53:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-28 20:53:58 --> 404 Page Not Found: Cookie-policyhtml/index
ERROR - 2021-02-28 21:01:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-28 21:03:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-28 21:05:06 --> 404 Page Not Found: Faviconico/index
