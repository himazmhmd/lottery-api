<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-23 03:41:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-23 03:41:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-23 03:48:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-23 13:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-23 13:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-23 17:10:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-23 17:10:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-23 19:14:34 --> 404 Page Not Found: Robotstxt/index
