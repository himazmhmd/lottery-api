<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-24 05:10:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-24 05:10:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-24 05:10:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-24 05:10:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-24 05:39:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-24 12:16:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-24 16:03:47 --> 404 Page Not Found: Robotstxt/index
