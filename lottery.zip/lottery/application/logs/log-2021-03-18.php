<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-18 10:30:02 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-18 17:40:08 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-18 22:49:00 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
