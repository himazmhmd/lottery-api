<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-12 21:55:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-12 21:55:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-12 21:55:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
