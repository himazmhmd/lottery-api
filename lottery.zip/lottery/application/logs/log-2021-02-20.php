<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-20 11:34:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-20 11:34:34 --> Unable to connect to the database
ERROR - 2021-02-20 11:34:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-20 11:34:37 --> Unable to connect to the database
ERROR - 2021-02-20 11:34:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-20 11:51:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:51:28 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-20 11:52:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:52:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:53:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:53:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:53:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:54:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:54:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:55:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:56:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:57:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:57:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:57:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:58:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 11:58:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:00:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:01:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:04:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:05:15 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:05:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:05:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:05:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:09:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:14:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Home/nicepage.css
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Home/Home.css
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Home/jquery.js
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Home/nicepage.js
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Home/images
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Home/images
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Home/Home.css
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Home/nicepage.js
ERROR - 2021-02-20 12:27:02 --> 404 Page Not Found: Home/jquery.js
