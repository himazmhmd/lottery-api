<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-11 06:29:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:29:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-11 06:29:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:29:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:42:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:42:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:42:49 --> 404 Page Not Found: Payment/favicon.ico
ERROR - 2021-03-11 06:42:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:42:53 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-11 06:43:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:43:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:43:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:43:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:44:25 --> Severity: Notice --> Undefined variable: package_id /home/quetjoxq/lottery.quetech.info/application/controllers/Home.php 221
ERROR - 2021-03-11 06:44:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:44:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:44:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:45:04 --> Severity: Warning --> fopen(/home/quetjoxq/lottery.quetech.info/system/logs/paypal_ipn.log): failed to open stream: No such file or directory /home/quetjoxq/lottery.quetech.info/application/libraries/Paypal_lib.php 229
ERROR - 2021-03-11 06:45:04 --> Severity: Warning --> fwrite() expects parameter 1 to be resource, boolean given /home/quetjoxq/lottery.quetech.info/application/libraries/Paypal_lib.php 230
ERROR - 2021-03-11 06:45:04 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /home/quetjoxq/lottery.quetech.info/application/libraries/Paypal_lib.php 232
ERROR - 2021-03-11 06:45:27 --> Severity: Notice --> Undefined variable: package_id /home/quetjoxq/lottery.quetech.info/application/controllers/Home.php 221
ERROR - 2021-03-11 06:45:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:45:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:46:04 --> Severity: Warning --> fopen(/home/quetjoxq/lottery.quetech.info/system/logs/paypal_ipn.log): failed to open stream: No such file or directory /home/quetjoxq/lottery.quetech.info/application/libraries/Paypal_lib.php 229
ERROR - 2021-03-11 06:46:04 --> Severity: Warning --> fwrite() expects parameter 1 to be resource, boolean given /home/quetjoxq/lottery.quetech.info/application/libraries/Paypal_lib.php 230
ERROR - 2021-03-11 06:46:04 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /home/quetjoxq/lottery.quetech.info/application/libraries/Paypal_lib.php 232
ERROR - 2021-03-11 06:46:26 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:50:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:50:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:50:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:50:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:52:16 --> Severity: Notice --> Trying to get property 'title' of non-object /home/quetjoxq/lottery.quetech.info/application/models/admin/Crud_model.php 14
ERROR - 2021-03-11 06:52:16 --> Severity: Notice --> Trying to get property 'no_of_tickets' of non-object /home/quetjoxq/lottery.quetech.info/application/models/admin/Crud_model.php 20
ERROR - 2021-03-11 06:52:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:52:19 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-11 06:52:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:52:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-11 06:52:38 --> Severity: Notice --> Trying to get property 'title' of non-object /home/quetjoxq/lottery.quetech.info/application/models/admin/Crud_model.php 14
ERROR - 2021-03-11 06:52:38 --> Severity: Notice --> Trying to get property 'no_of_tickets' of non-object /home/quetjoxq/lottery.quetech.info/application/models/admin/Crud_model.php 20
ERROR - 2021-03-11 06:52:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:52:58 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:53:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:53:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 06:53:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:01:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:01:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:01:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:03:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:04:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:05:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:08:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:08:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:09:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:11:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:14:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:14:28 --> Severity: Notice --> Undefined property: stdClass::$name /home/quetjoxq/lottery.quetech.info/application/views/front/ticket_template.php 6
ERROR - 2021-03-11 07:14:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:16:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:16:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:20:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:20:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:22:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:22:56 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:24:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:24:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:38:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-11 07:41:14 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:42:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:42:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:42:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:42:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 07:42:30 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 08:00:58 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 08:02:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 14:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-11 14:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-11 23:22:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 23:22:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 23:22:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 23:22:20 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-11 23:22:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-11 23:22:20 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-11 23:22:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-11 23:22:21 --> 404 Page Not Found: Faviconico/index
