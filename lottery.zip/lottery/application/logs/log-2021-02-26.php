<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-26 07:47:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 07:47:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 07:47:46 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 07:53:38 --> 404 Page Not Found: Winnershtml/index
ERROR - 2021-02-26 07:54:01 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 07:56:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 10:52:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 11:02:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 11:03:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 11:06:15 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 11:19:34 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\lottery\application\controllers\Home.php 51
ERROR - 2021-02-26 11:30:01 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 11:36:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 11:39:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:39:01 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 11:39:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:40:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:40:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:41:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:41:12 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 11:41:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:41:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:41:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 11:41:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:41:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:43:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 11:43:24 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 11:56:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:01:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:03:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:04:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:04:13 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 12:04:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:04:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:04:38 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:05:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:06:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:06:07 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 12:06:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:06:16 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 12:18:08 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 12:18:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:18:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:18:35 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 12:23:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:23:39 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 12:23:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:23:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:25:29 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\lottery\application\controllers\Home.php 38
ERROR - 2021-02-26 12:25:44 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result_array() C:\xampp\htdocs\lottery\application\controllers\Home.php 38
ERROR - 2021-02-26 12:26:02 --> Severity: error --> Exception: Call to a member function num_rows() on array C:\xampp\htdocs\lottery\application\controllers\Home.php 41
ERROR - 2021-02-26 12:28:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:29:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:29:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:30:30 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:30:30 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 12:30:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:30:48 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 12:30:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:31:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:34:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 12:34:35 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 12:34:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:35:58 --> Severity: error --> Exception: Call to a member function num_rows() on array C:\xampp\htdocs\lottery\application\controllers\Home.php 42
ERROR - 2021-02-26 12:39:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:39:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:39:34 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\lottery\application\controllers\Home.php 48
ERROR - 2021-02-26 12:40:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 12:43:37 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 12:55:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 13:00:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 13:01:17 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 13:01:17 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 13:02:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 13:02:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 13:07:00 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 13:07:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 13:07:13 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 13:07:24 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\lottery\application\controllers\Home.php 41
ERROR - 2021-02-26 13:09:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 13:09:16 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 13:09:42 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 13:09:42 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 13:11:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 13:11:23 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 13:23:50 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 09:05:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 17:50:57 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:51:29 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:51:34 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:51:45 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:52:05 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:52:13 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:52:19 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:52:33 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:53:18 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:54:59 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:55:18 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:58:52 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:58:59 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:59:04 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 17:59:09 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 18:01:07 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 18:07:45 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 18:07:55 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 18:13:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 18:17:27 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\lottery\application\controllers\Home.php 72
ERROR - 2021-02-26 18:19:46 --> Severity: Notice --> Undefined index: admin_id C:\xampp\htdocs\lottery\application\controllers\Home.php 50
ERROR - 2021-02-26 18:19:46 --> Severity: Notice --> Undefined index: admin_role_id C:\xampp\htdocs\lottery\application\controllers\Home.php 52
ERROR - 2021-02-26 18:19:46 --> Severity: Notice --> Undefined index: admin_role_title C:\xampp\htdocs\lottery\application\controllers\Home.php 53
ERROR - 2021-02-26 18:19:46 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\lottery\application\controllers\Home.php 54
ERROR - 2021-02-26 18:19:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-26 18:20:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 18:20:40 --> Severity: Notice --> Undefined index: admin_id C:\xampp\htdocs\lottery\application\controllers\Home.php 50
ERROR - 2021-02-26 18:20:40 --> Severity: Notice --> Undefined index: admin_role_id C:\xampp\htdocs\lottery\application\controllers\Home.php 52
ERROR - 2021-02-26 18:20:40 --> Severity: Notice --> Undefined index: admin_role_title C:\xampp\htdocs\lottery\application\controllers\Home.php 53
ERROR - 2021-02-26 18:20:40 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\lottery\application\controllers\Home.php 54
ERROR - 2021-02-26 18:22:02 --> Severity: Notice --> Undefined index: admin_id C:\xampp\htdocs\lottery\application\controllers\Home.php 51
ERROR - 2021-02-26 18:22:02 --> Severity: Notice --> Undefined index: admin_role_id C:\xampp\htdocs\lottery\application\controllers\Home.php 53
ERROR - 2021-02-26 18:22:02 --> Severity: Notice --> Undefined index: admin_role_title C:\xampp\htdocs\lottery\application\controllers\Home.php 54
ERROR - 2021-02-26 18:22:02 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\lottery\application\controllers\Home.php 55
ERROR - 2021-02-26 18:22:14 --> Severity: Notice --> Undefined index: admin_id C:\xampp\htdocs\lottery\application\controllers\Home.php 51
ERROR - 2021-02-26 18:22:14 --> Severity: Notice --> Undefined index: admin_role_id C:\xampp\htdocs\lottery\application\controllers\Home.php 53
ERROR - 2021-02-26 18:22:14 --> Severity: Notice --> Undefined index: admin_role_title C:\xampp\htdocs\lottery\application\controllers\Home.php 54
ERROR - 2021-02-26 18:22:14 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\lottery\application\controllers\Home.php 55
ERROR - 2021-02-26 18:23:18 --> Severity: Notice --> Undefined index: admin_role_id C:\xampp\htdocs\lottery\application\controllers\Home.php 53
ERROR - 2021-02-26 18:23:18 --> Severity: Notice --> Undefined index: admin_role_title C:\xampp\htdocs\lottery\application\controllers\Home.php 54
ERROR - 2021-02-26 18:23:18 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\lottery\application\controllers\Home.php 55
ERROR - 2021-02-26 18:25:53 --> Severity: Notice --> Undefined variable: admin_data C:\xampp\htdocs\lottery\application\controllers\Home.php 58
ERROR - 2021-02-26 18:27:39 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-26 18:29:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 18:29:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 18:29:43 --> 404 Page Not Found: admin/Dashboard/index3
ERROR - 2021-02-26 18:30:01 --> 404 Page Not Found: admin/Dashboard/index3
ERROR - 2021-02-26 18:30:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-26 18:32:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 18:32:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-26 18:34:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-26 18:34:26 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-26 18:34:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 18:36:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 18:37:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 18:37:06 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 22:37:13 --> Severity: Notice --> Undefined property: Userdashboard::$dashboard_model C:\xampp\htdocs\lottery\application\controllers\admin\Userdashboard.php 21
ERROR - 2021-02-26 22:37:13 --> Severity: error --> Exception: Call to a member function get_all_users() on null C:\xampp\htdocs\lottery\application\controllers\admin\Userdashboard.php 21
ERROR - 2021-02-26 22:37:39 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 22:37:39 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 22:37:39 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 18:39:16 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-26 22:39:18 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 22:39:18 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 22:39:18 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 18:39:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-26 22:39:23 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 22:39:23 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 22:39:23 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 18:39:31 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 22:39:34 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 22:39:34 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 22:39:34 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 18:39:39 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 22:40:36 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 22:40:36 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 22:40:36 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 22:52:04 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 22:52:04 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 22:52:04 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:05:30 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:05:30 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:05:30 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:06:03 --> Severity: Notice --> Undefined variable: nav C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 37
ERROR - 2021-02-26 23:06:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 37
ERROR - 2021-02-26 23:06:03 --> Severity: Notice --> Undefined variable: nav C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 39
ERROR - 2021-02-26 23:06:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 39
ERROR - 2021-02-26 23:06:04 --> Could not find the language line ""
ERROR - 2021-02-26 23:06:04 --> Severity: Notice --> Undefined variable: has_submenu C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 40
ERROR - 2021-02-26 23:06:04 --> Severity: Notice --> Undefined variable: has_submenu C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 46
ERROR - 2021-02-26 23:06:04 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:06:04 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:06:04 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:06:22 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file C:\xampp\htdocs\lottery\application\views\admin\includes\userside.php 69
ERROR - 2021-02-26 23:06:28 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:06:28 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:06:28 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:08:10 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:08:10 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:08:10 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:08:45 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:08:45 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:08:45 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 19:08:49 --> 404 Page Not Found: admin/Indexhtml/index
ERROR - 2021-02-26 23:08:50 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:08:50 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:08:50 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:09:25 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:09:25 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:09:25 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:17:45 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:17:45 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:17:45 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:17:46 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:17:46 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:17:46 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:22:50 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:22:50 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:22:50 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:22:51 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:22:51 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:22:51 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:22:53 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:22:53 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:22:53 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 19:23:12 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 23:23:15 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:23:15 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:23:15 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:26:48 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:26:48 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:26:48 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:31:48 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:31:48 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:31:48 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 19:31:54 --> 404 Page Not Found: admin/Indexhtml/index
ERROR - 2021-02-26 23:31:56 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:31:56 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:31:56 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:32:37 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:32:37 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:32:37 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 19:32:40 --> 404 Page Not Found: admin/Pages/layout
ERROR - 2021-02-26 23:32:41 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:32:41 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:32:41 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:32:51 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:32:51 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:32:51 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:33:39 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:33:39 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:33:39 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:33:52 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:33:52 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:33:52 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:35:21 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:35:21 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:35:21 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:35:37 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:35:37 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:35:37 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:35:49 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:35:49 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:35:49 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:42:43 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:42:43 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:42:43 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:43:05 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:43:05 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:43:05 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:43:19 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:43:19 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:43:19 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:43:46 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:43:46 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:43:46 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 19:44:02 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 23:44:49 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:44:49 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:44:49 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:45:30 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:45:30 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:45:30 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:45:58 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:45:58 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:45:58 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:46:14 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:46:14 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:46:14 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 23:52:35 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:52:35 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:52:35 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 19:52:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 19:52:39 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-26 23:52:59 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:52:59 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:52:59 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 19:53:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 19:53:14 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 23:53:32 --> Severity: Notice --> Undefined variable: all_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 31
ERROR - 2021-02-26 23:53:32 --> Severity: Notice --> Undefined variable: active_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 46
ERROR - 2021-02-26 23:53:32 --> Severity: Notice --> Undefined variable: deactive_users C:\xampp\htdocs\lottery\application\views\admin\dashboard\index.php 61
ERROR - 2021-02-26 20:02:30 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 20:03:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 20:41:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 20:42:01 --> 404 Page Not Found: Home/userdashboard
ERROR - 2021-02-26 20:42:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 20:42:19 --> 404 Page Not Found: Dashboard/index
ERROR - 2021-02-26 20:42:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-26 09:03:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-26 09:03:51 --> Unable to connect to the database
ERROR - 2021-02-26 09:03:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-26 09:03:54 --> Unable to connect to the database
ERROR - 2021-02-26 09:04:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-26 09:02:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-26 09:02:37 --> Unable to connect to the database
ERROR - 2021-02-26 09:02:55 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-26 09:03:00 --> 404 Page Not Found: Faviconico/index
