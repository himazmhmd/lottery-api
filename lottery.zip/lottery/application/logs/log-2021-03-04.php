<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-04 02:42:11 --> Severity: Notice --> Trying to get property 'title' of non-object /home/quetjoxq/lottery.quetech.info/application/models/admin/User_model.php 32
ERROR - 2021-03-04 02:42:11 --> Severity: Notice --> Undefined index: created_at /home/quetjoxq/lottery.quetech.info/application/controllers/admin/Users.php 76
ERROR - 2021-03-04 02:45:00 --> Severity: Notice --> Trying to get property 'title' of non-object /home/quetjoxq/lottery.quetech.info/application/models/admin/User_model.php 32
ERROR - 2021-03-04 02:45:36 --> Severity: Notice --> Trying to get property 'title' of non-object /home/quetjoxq/lottery.quetech.info/application/models/admin/User_model.php 32
ERROR - 2021-03-04 02:47:46 --> Severity: Notice --> Trying to get property 'title' of non-object /home/quetjoxq/lottery.quetech.info/application/models/admin/User_model.php 32
ERROR - 2021-03-04 02:53:50 --> Severity: Notice --> Trying to get property 'title' of non-object /home/quetjoxq/lottery.quetech.info/application/models/admin/User_model.php 32
ERROR - 2021-03-04 03:14:05 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-04 03:14:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-04 03:14:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-04 03:14:24 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-04 06:06:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:06:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-04 06:20:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:20:25 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-04 06:27:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:27:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-04 06:28:40 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:34:30 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:34:39 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:34:39 --> 404 Page Not Found: Payment/favicon.ico
ERROR - 2021-03-04 06:34:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:34:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:34:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:35:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:35:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:35:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:35:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:36:24 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:36:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:36:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:36:41 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:36:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:37:01 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:37:02 --> 404 Page Not Found: Edit_settings/favicon.ico
ERROR - 2021-03-04 06:37:07 --> Query error: Duplicate entry 'muhammadaafaq53@gmail.com' for key 'email' - Invalid query: UPDATE `ci_users` SET `firstname` = 'test user', `lastname` = 'abc', `username` = 'test userabc', `email` = 'muhammadaafaq53@gmail.com', `card_number` = '2123324', `exp_month` = 'aaa', `country` = 'Pakistan', `mobile_no` = '+923333755774'
WHERE `id` = '64'
ERROR - 2021-03-04 06:37:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:37:29 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:37:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:38:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:38:00 --> 404 Page Not Found: Change_password/favicon.ico
ERROR - 2021-03-04 06:38:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:38:11 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:38:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:38:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:40:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:40:18 --> Severity: Warning --> fopen(/home/quetjoxq/lottery.quetech.info/system/logs/paypal_ipn.log): failed to open stream: No such file or directory /home/quetjoxq/lottery.quetech.info/application/libraries/Paypal_lib.php 229
ERROR - 2021-03-04 06:40:18 --> Severity: Warning --> fwrite() expects parameter 1 to be resource, boolean given /home/quetjoxq/lottery.quetech.info/application/libraries/Paypal_lib.php 230
ERROR - 2021-03-04 06:40:18 --> Severity: Warning --> fclose() expects parameter 1 to be resource, boolean given /home/quetjoxq/lottery.quetech.info/application/libraries/Paypal_lib.php 232
ERROR - 2021-03-04 06:40:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:40:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:41:42 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:41:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:41:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:41:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:42:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:42:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:43:03 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-04 06:45:04 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-04 06:45:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:46:19 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 06:46:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 09:20:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 09:20:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-04 09:21:00 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-04 09:33:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-04 09:33:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-04 09:33:57 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-04 09:34:15 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-04 20:51:17 --> Severity: error --> Exception: syntax error, unexpected '>' /home/quetjoxq/lottery.quetech.info/application/controllers/Paypal.php 86
