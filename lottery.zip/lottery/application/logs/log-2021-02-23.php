<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-23 11:20:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Home/nicepage.css
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Home/Home.css
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Home/jquery.js
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Home/nicepage.js
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Home/images
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Home/images
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Home/Home.css
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Home/nicepage.js
ERROR - 2021-02-23 11:23:25 --> 404 Page Not Found: Home/jquery.js
ERROR - 2021-02-23 11:23:26 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-23 11:25:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:27:46 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:29:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:29:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:31:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:32:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:32:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:32:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:33:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:33:16 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:33:23 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:34:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:34:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:34:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:45:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:45:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:46:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:46:53 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:46:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:46:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:47:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:47:21 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:47:43 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:51:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:51:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:52:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 11:53:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 12:28:12 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-23 12:31:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 12:32:44 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 12:32:49 --> 404 Page Not Found: Howitworks/index
ERROR - 2021-02-23 12:39:13 --> Severity: Notice --> Undefined variable: plans C:\xampp\htdocs\lottery\application\views\front\plans.php 66
ERROR - 2021-02-23 12:39:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\lottery\application\views\front\plans.php 66
ERROR - 2021-02-23 12:43:13 --> Severity: Notice --> Undefined variable: plans C:\xampp\htdocs\lottery\application\views\front\plans.php 66
ERROR - 2021-02-23 12:43:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\lottery\application\views\front\plans.php 66
ERROR - 2021-02-23 12:43:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-23 12:48:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-23 13:02:30 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 13:02:30 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-02-23 13:16:55 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 13:17:45 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 13:18:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 13:18:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 13:18:49 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 13:19:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 13:21:57 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 14:07:27 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-23 14:50:06 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-23 14:50:18 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-23 14:55:35 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-23 14:56:53 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-23 14:59:39 --> 404 Page Not Found: Assets/dist
