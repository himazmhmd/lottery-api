<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-17 17:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-17 17:10:17 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-17 17:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-17 17:10:24 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-17 17:10:28 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
ERROR - 2021-03-17 17:12:16 --> Severity: Core Warning --> Module 'sqlite3' already loaded Unknown 0
