<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-28 13:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-28 13:58:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-28 13:58:08 --> 404 Page Not Found: Faviconico/index
