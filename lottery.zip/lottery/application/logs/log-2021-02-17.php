<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-17 10:10:19 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-17 10:15:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-17 10:23:26 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-17 10:27:27 --> 404 Page Not Found: Access_denied/index
ERROR - 2021-02-17 10:29:14 --> 404 Page Not Found: /index
ERROR - 2021-02-17 10:29:17 --> 404 Page Not Found: /index
ERROR - 2021-02-17 10:29:40 --> 404 Page Not Found: /index
ERROR - 2021-02-17 10:30:30 --> 404 Page Not Found: /index
ERROR - 2021-02-17 10:32:04 --> 404 Page Not Found: /index
ERROR - 2021-02-17 10:32:20 --> 404 Page Not Found: /index
ERROR - 2021-02-17 10:33:16 --> 404 Page Not Found: /index
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/css
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/images
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2021-02-17 10:53:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-17 10:58:50 --> 404 Page Not Found: Register/index
ERROR - 2021-02-17 11:00:21 --> 404 Page Not Found: Register/index
ERROR - 2021-02-17 11:01:56 --> 404 Page Not Found: Home/login
ERROR - 2021-02-17 11:03:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-17 11:03:24 --> 404 Page Not Found: Howitworks/index
ERROR - 2021-02-17 11:03:29 --> 404 Page Not Found: Home/login
ERROR - 2021-02-17 12:52:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-17 13:06:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-17 13:06:53 --> Unable to connect to the database
ERROR - 2021-02-17 13:06:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\lottery\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-02-17 13:06:59 --> Unable to connect to the database
ERROR - 2021-02-17 13:10:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-17 13:20:04 --> Query error: Table 'lot.users' doesn't exist - Invalid query: INSERT INTO `users` (`first_name`, `sur_name`, `email`, `password`, `term`, `BO_1`, `BO_2`, `BO_3`, `BO_4`, `BO_5`, `BO_6`) VALUES ('afaq', 'khan', 'afaq@gmail.com', '12345', '1', '32', '37', '9', '44', '41', '61')
ERROR - 2021-02-17 13:22:35 --> Query error: Unknown column 'first_name' in 'field list' - Invalid query: INSERT INTO `ci_users` (`first_name`, `sur_name`, `email`, `password`, `term`, `BO_1`, `BO_2`, `BO_3`, `BO_4`, `BO_5`, `BO_6`) VALUES ('afaq', 'khan', 'afaq@gmail.com', '12345', '1', '32', '37', '9', '44', '41', '61')
ERROR - 2021-02-17 13:26:53 --> Query error: Unknown column 'term' in 'field list' - Invalid query: INSERT INTO `ci_users` (`firstname`, `lastname`, `username`, `email`, `password`, `term`, `BO_1`, `BO_2`, `BO_3`, `BO_4`, `BO_5`, `BO_6`) VALUES ('afaq', 'khan', 'afaqkhan', 'afaq@gmail.com', '12345', '1', '32', '37', '9', '44', '41', '61')
ERROR - 2021-02-17 13:29:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-17 13:29:35 --> 404 Page Not Found: Access_denied/index
ERROR - 2021-02-17 13:34:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-17 13:37:03 --> 404 Page Not Found: admin//index
ERROR - 2021-02-17 13:37:08 --> 404 Page Not Found: admin//index
ERROR - 2021-02-17 13:39:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-17 13:40:03 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-17 13:40:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-17 13:42:41 --> 404 Page Not Found: admin//index
ERROR - 2021-02-17 13:42:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-02-17 13:42:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-17 13:42:54 --> 404 Page Not Found: admin//index
ERROR - 2021-02-17 13:42:59 --> 404 Page Not Found: admin//index
ERROR - 2021-02-17 13:43:08 --> 404 Page Not Found: admin//index
ERROR - 2021-02-17 13:45:44 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-17 13:46:13 --> 404 Page Not Found: Public/bootstrap
