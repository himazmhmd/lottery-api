<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-16 03:19:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-16 03:29:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-16 03:29:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-16 06:20:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-16 06:20:32 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-16 06:20:35 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-16 06:20:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-16 06:20:36 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-16 11:58:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-16 12:00:07 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-16 12:10:39 --> 404 Page Not Found: Assets/dist
