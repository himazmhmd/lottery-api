<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-18 10:30:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-18 10:32:09 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 10:32:22 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 10:32:28 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 10:39:51 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 10:41:09 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 10:56:01 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:00:54 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:00:59 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:01:07 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:04:51 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:05:14 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:06:05 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:06:20 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:08:07 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:08:13 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:10:35 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 00:10:41 --> Severity: Warning --> Illegal string offset 'is_verify' C:\xampp\htdocs\lottery\application\controllers\admin\Auth.php 47
ERROR - 2021-02-18 11:10:51 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 00:13:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\lottery\application\controllers\admin\Auth.php 44
ERROR - 2021-02-18 11:25:10 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:27:42 --> 404 Page Not Found: admin//index
ERROR - 2021-02-18 11:27:46 --> 404 Page Not Found: admin//index
ERROR - 2021-02-18 11:27:55 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:28:06 --> 404 Page Not Found: admin//index
ERROR - 2021-02-18 11:28:29 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-02-18 11:28:39 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:36:11 --> 404 Page Not Found: admin//index
ERROR - 2021-02-18 11:36:15 --> 404 Page Not Found: admin//index
ERROR - 2021-02-18 11:36:34 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 11:46:09 --> Severity: Notice --> date_default_timezone_set(): Timezone ID '' is invalid C:\xampp\htdocs\lottery\application\core\MY_Controller.php 27
ERROR - 2021-02-18 11:46:25 --> Severity: Notice --> date_default_timezone_set(): Timezone ID '' is invalid C:\xampp\htdocs\lottery\application\core\MY_Controller.php 27
ERROR - 2021-02-18 15:51:47 --> Severity: Notice --> Undefined property: Export::$ignore_directories C:\xampp\htdocs\lottery\application\controllers\admin\Export.php 44
ERROR - 2021-02-18 15:51:48 --> Severity: Notice --> Only variables should be assigned by reference C:\xampp\htdocs\lottery\application\controllers\admin\Export.php 56
ERROR - 2021-02-18 11:53:28 --> 404 Page Not Found: admin//index
ERROR - 2021-02-18 12:01:32 --> 404 Page Not Found: admin//index
ERROR - 2021-02-18 12:09:25 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 12:09:49 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 12:19:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-18 12:32:38 --> 404 Page Not Found: Assets/dist
ERROR - 2021-02-18 12:33:24 --> 404 Page Not Found: Registerhtml/index
ERROR - 2021-02-18 16:51:58 --> Could not find the language line "Packages"
ERROR - 2021-02-18 16:51:58 --> Could not find the language line "Packages"
ERROR - 2021-02-18 16:52:07 --> Could not find the language line "Packages"
ERROR - 2021-02-18 16:54:44 --> Could not find the language line "Packages"
ERROR - 2021-02-18 16:57:15 --> Could not find the language line "Packages list"
ERROR - 2021-02-18 16:57:15 --> Could not find the language line "Packages list"
ERROR - 2021-02-18 16:57:19 --> Could not find the language line "Packages list"
ERROR - 2021-02-18 12:58:10 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-18 12:59:30 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-18 13:00:21 --> 404 Page Not Found: admin/Packages/index
ERROR - 2021-02-18 20:17:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-02-18 20:24:53 --> 404 Page Not Found: admin//index
ERROR - 2021-02-18 20:25:00 --> 404 Page Not Found: Assets/dist
