<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-07 02:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-07 23:34:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-07 23:34:47 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-07 23:34:48 --> 404 Page Not Found: Faviconico/index
