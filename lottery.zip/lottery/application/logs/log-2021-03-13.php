<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-13 12:55:37 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-13 12:55:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 16:16:36 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-13 16:16:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 16:16:43 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-13 16:35:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 16:38:05 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-13 16:38:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-13 16:47:33 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-13 16:54:17 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-13 17:14:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 17:16:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 17:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 17:18:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 17:20:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 17:24:27 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-13 17:29:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 17:29:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-13 17:30:25 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-13 17:30:28 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-13 17:34:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-13 17:39:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-13 17:39:12 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
