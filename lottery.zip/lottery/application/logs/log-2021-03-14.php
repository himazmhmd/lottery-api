<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-14 02:16:48 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:35:14 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:35:24 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:36:31 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:36:59 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:44:50 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:44:55 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:45:08 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:47:43 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:47:44 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:47:45 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:47:46 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:47:47 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:47:49 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:47:53 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:47:54 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:54:23 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:54:25 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:55:20 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 02:55:23 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:08:17 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:08:18 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:08:21 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:14:23 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:14:35 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:16:01 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:16:46 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:18:01 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:18:23 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:18:27 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:18:28 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:18:30 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:18:31 --> Could not find the language line "draw_settings
"
ERROR - 2021-03-14 03:19:12 --> Could not find the language line "dr_setting
"
ERROR - 2021-03-14 03:19:15 --> Could not find the language line "dr_setting
"
ERROR - 2021-03-14 03:20:16 --> Could not find the language line "dr_setting
"
ERROR - 2021-03-14 03:22:11 --> Could not find the language line "Draw Setting"
ERROR - 2021-03-14 03:22:13 --> Could not find the language line "Draw Setting"
ERROR - 2021-03-14 03:22:21 --> Could not find the language line "Draw Setting"
ERROR - 2021-03-14 03:22:41 --> Could not find the language line "Draw Setting"
ERROR - 2021-03-14 03:24:33 --> Could not find the language line "Draw Setting"
ERROR - 2021-03-14 03:29:09 --> Could not find the language line ""
ERROR - 2021-03-14 03:29:14 --> Could not find the language line ""
ERROR - 2021-03-14 00:20:51 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 00:20:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 00:20:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-14 00:20:58 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 00:20:58 --> 404 Page Not Found: Home/favicon.ico
ERROR - 2021-03-14 00:21:02 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 00:21:06 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 00:21:07 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 00:21:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 00:21:59 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 03:40:50 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 03:40:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-14 03:40:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 03:42:40 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-14 03:43:31 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 03:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-14 03:52:48 --> Severity: Notice --> Undefined variable: day /home/quetjoxq/lottery.quetech.info/application/views/front/winners.php 22
ERROR - 2021-03-14 03:52:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 03:54:58 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 03:55:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-14 04:02:08 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 04:03:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-14 04:04:48 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 04:05:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 04:05:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 04:06:09 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 04:09:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-14 04:09:52 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 04:10:18 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-14 04:25:54 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
