<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-22 00:04:09 --> Could not find the language line "winners"
ERROR - 2021-03-22 00:04:09 --> Could not find the language line "winners"
ERROR - 2021-03-22 02:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-22 03:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-03-22 06:59:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-22 07:00:38 --> 404 Page Not Found: admin/Winners/winners
ERROR - 2021-03-22 07:00:42 --> 404 Page Not Found: Assets/dist
ERROR - 2021-03-22 07:21:22 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-22 07:21:31 --> 404 Page Not Found: admin/Winners/winners
ERROR - 2021-03-22 07:22:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-22 16:25:34 --> Query error: Table 'quetjoxq_lotetery.winners' doesn't exist - Invalid query: INSERT INTO `winners` (`name`, `image`, `message`) VALUES ('Muhammad Aafaq', 'winner-claire.jpg', 'this is test message')
ERROR - 2021-03-22 16:28:56 --> Query error: Unknown column 'image' in 'field list' - Invalid query: INSERT INTO `winners` (`name`, `image`, `message`) VALUES ('Muhammad Aafaq', 'winner-claire1.jpg', 'this is test message')
ERROR - 2021-03-22 07:30:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-22 07:31:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-22 07:44:10 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-22 07:44:12 --> Severity: Notice --> Undefined variable: winners /home/quetjoxq/lottery.quetech.info/application/views/front/winners.php 34
ERROR - 2021-03-22 07:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/quetjoxq/lottery.quetech.info/application/views/front/winners.php 34
ERROR - 2021-03-22 07:44:13 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-22 07:45:20 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-22 07:45:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-22 21:11:00 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-22 21:11:03 --> 404 Page Not Found: Wwwgoogle-analyticscom/analytics.js
ERROR - 2021-03-22 21:11:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-03-22 21:11:05 --> 404 Page Not Found: Faviconico/index
